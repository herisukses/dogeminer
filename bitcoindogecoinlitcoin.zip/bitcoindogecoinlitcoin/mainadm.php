<?Php
ini_set('display_errors', 0);
error_reporting(0);
include_once("asdm.php");
if(empty($alogina) and empty($apassworda)){
require("mainentr.php");
}
else{
require("dashadm.php");
}
?>