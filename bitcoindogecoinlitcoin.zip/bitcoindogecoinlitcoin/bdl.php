<?php
mysql_connect ("localhost","DATABBASE USER","DATABSE PASS");
mysql_select_db ("DATABASE NAME");
?>