<!DOCTYPE HTML>
<html>
	<head>
		<title>TCC</title>
        <link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
		<div id="page-wrapper">
			<!-- Header -->
				<header id="header" class="alt">
					<h1 id="logo"><a href="mainentr.html">TCC<span> Cloud mining cryptocurrency</span></a></h1>
				</header>

			<!-- Banner -->
				<section id="banner">
					<!--
						".inner" is set up as an inline-block so it automatically expands
						in both directions to fit whatever's inside it. This means it won't
						automatically wrap lines, so be sure to use line breaks where
						appropriate (<br />).
					-->
					<div class="inner">

						<header>
							<h2>TCC mining ADMIN_PANEL</h2>
						</header>
                           <ul class="buttons vertical">
								<li><a href="javascript:look('divone');" class="button fit scrolly">Sign In</a></li>
							</ul>
                            <div id="divone" style="display:none">
	                        <form action="lgadm.php" name="frmLogin" method="post">
	                        <input name="login" type="text" id="login" placeholder = "login" Style="border-radius: 10px;" required><br>
	                        <input name="password" type="password" id="password" placeholder = "password" Style="border-radius: 10px;" required><br>
	                        <input type="submit" value="GO" name="submit"  title="SIGN IN" Style="border-radius: 10px;"><br>
                            </form>
                            </div>
					</div>
				</section>
		</div>

		<!-- Scripts -->
             <script>
               function look(type){
                param=document.getElementById(type);
                if(param.style.display == "none") param.style.display = "block";
                else param.style.display = "none"
             }
            </script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>