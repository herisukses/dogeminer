<?php
include("bd.php");

if (isset($_GET['act']) AND isset($_GET['login'])) {
	$act = $_GET['act'];
	$act = stripslashes($act);
	$act = htmlspecialchars($act);
	
	$login = $_GET['login'];
	$login = stripslashes($login);
	$login = htmlspecialchars($login);
}
else{
	exit("You went to the page without confirmation code!");
}


$activ = mysql_query("SELECT id FROM gusers WHERE glogin='$login'"); 
$id_activ = mysql_fetch_array($activ); 

$activation = md5($id_activ['id']);

if ($activation == $act) {
    $rlkdate = date("d-m-Y  H:i");
	mysql_query("UPDATE gusers SET activation='1' WHERE glogin='$login'");
	mysql_query("UPDATE ltcdoge SET activation='1' WHERE flogin='$login'");
	mysql_query("UPDATE ltcdogeming SET activation='1' WHERE vlogin='$login'");
	mysql_query("UPDATE greffer SET activation='1' WHERE rlogin='$login'");
    mysql_query("UPDATE gsmcnew SET activation='1' WHERE slogin='$login'"); 
	$datehis = $rlkdate." - "."registration";
	$filehist = 'histor/'.$activation.".txt";
	$fphis = fopen ($filehist, "w"); 
	fwrite($fphis,$datehis);  
    fclose($fphis); 
    include_once("activvis.php");
}
else {
	echo "Error! Your account is not activated. Contact administrator.<br><a href='index.php'>...MAIN PAGE</a>";
}

?>
<style type="text/css">
<!--
body {
	font-size: 24px;
}
-->
</style>