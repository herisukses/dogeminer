<?Php
include_once("bd.php");
require_once("pwinc12.php");
require_once("lib/block_io.php");
mysql_query("UPDATE gusers SET flnmb = 'pwinc12' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");
$block_io = new BlockIo($apiKey, $pin, $version);
//---------------------------------------------
$DBDeprite = mysql_query("SELECT deposit, pressblock FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayDEPrite = mysql_fetch_array($DBDeprite) or die(mysql_error());
$Mydepr = $arrayDEPrite['pressblock'];
$MdepBit = $arrayDEPrite['deposit'];
//---------------------------------------------
if ($Mydepr == "1") {
echo "<script>alert(\"Do you already have a generated address! ".$MdepBit."\");</script>";
 header("Refresh: 1; url=deposit.php");
exit;
}
else {
//---------------------------------------------
$newAddressInfo = $block_io->get_new_address();
$payTo =  $newAddressInfo->data->address;
$payLabel = $newAddressInfo->data->label;
mysql_query("UPDATE gusers SET deposit = '$payTo' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");	
mysql_query("UPDATE gusers SET paylabel = '$payLabel' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");	
}
?>