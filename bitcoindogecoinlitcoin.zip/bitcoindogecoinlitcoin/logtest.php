<?php
include_once("bd.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>TCC</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>

  <body>

<?php
if (isset($_POST['login'])) {
	$login = $_POST['login'];
	if ($login == '') {
		unset($login);
		exit ("Enter you login!");
	}
}
if (isset($_POST['password'])) {
	$password=$_POST['password'];
	if ($password =='') {
		unset($password);
		exit ("enter password");
	}
}

$login = stripslashes($login);
$login = htmlspecialchars($login);


$login = trim($login);

$user = mysql_query("SELECT id FROM gusers WHERE glogin='$login' AND gpassword='$password' AND activation='1'");
$id_user = mysql_fetch_array($user);
if (empty($id_user['id'])){
    include_once("main.html");
    echo "<script>alert(\"login or password are incorrect."."\");</script>";
	exit;
}
else {


    $_SESSION['password']=$password;
	$_SESSION['login']=$login;
    $_SESSION['id']=$id_user['id'];

}
echo "<meta http-equiv='Refresh' content='0; URL=index.php'>";
?>
</body>
</html>