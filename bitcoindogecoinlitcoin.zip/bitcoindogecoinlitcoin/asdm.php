<?php
session_start();

mysql_connect ("localhost","DATABASE USER","DATABASE PASS");
mysql_select_db ("DATABASE NAME");
$alogina = $_SESSION['login'];
$apassworda = $_SESSION['password'];
$aid_usera = $_SESSION['id'];
$aipa = $_SERVER['REMOTE_ADDR'];
?>