-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Client: localhost:3306
-- Généré le: Lun 27 Novembre 2017 à 00:46
-- Version du serveur: 10.1.24-MariaDB-cll-lve
-- Version de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `onlicpfq_tccscript`
--

-- --------------------------------------------------------

--
-- Structure de la table `costsmc`
--

CREATE TABLE IF NOT EXISTS `costsmc` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cost1` varchar(25) NOT NULL,
  `cost2` varchar(25) NOT NULL,
  `cost3` varchar(25) NOT NULL,
  `startdt` varchar(32) NOT NULL,
  `usdinbtc` varchar(25) NOT NULL,
  `dogeusd` varchar(25) NOT NULL,
  `ltcusd` varchar(25) NOT NULL,
  `dogebtc` varchar(25) NOT NULL,
  `ltcbtc` varchar(25) NOT NULL,
  `bnsB` varchar(25) NOT NULL,
  `bnsL` varchar(25) NOT NULL,
  `bnsD` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `costsmc`
--

INSERT INTO `costsmc` (`id`, `cost1`, `cost2`, `cost3`, `startdt`, `usdinbtc`, `dogeusd`, `ltcusd`, `dogebtc`, `ltcbtc`, `bnsB`, `bnsL`, `bnsD`) VALUES
(1, '0.00299000', '0.00100000', '0.00750000', '20-10-2016  08:38', '1216.35678477', '0.00020304', '3.81771768', '0.00000017', '0.00317770', '0.01000000', '0.10000000', '1000.00000000');

-- --------------------------------------------------------

--
-- Structure de la table `greffer`
--

CREATE TABLE IF NOT EXISTS `greffer` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `rlogin` varchar(20) CHARACTER SET latin1 NOT NULL,
  `rrpassword` varchar(35) CHARACTER SET latin1 NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `activation` int(1) NOT NULL,
  `reffer_id` varchar(50) CHARACTER SET latin1 NOT NULL,
  `my_refflink` varchar(50) CHARACTER SET latin1 NOT NULL,
  `name` varchar(32) CHARACTER SET latin1 NOT NULL,
  `datebonus` varchar(32) CHARACTER SET latin1 NOT NULL,
  `daycash` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `daycashdoge` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `daycashlite` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `countref` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `greffer`
--

INSERT INTO `greffer` (`id`, `rlogin`, `rrpassword`, `email`, `activation`, `reffer_id`, `my_refflink`, `name`, `datebonus`, `daycash`, `daycashdoge`, `daycashlite`, `countref`) VALUES
(7, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@z-files.site', 2, '', '', 'adminsmc', '', NULL, NULL, NULL, NULL),
(10, 'userd100', 'f838fba06070a82e0fd1c9eb8ce2c1a8', 'userd100@gmail.com', 1, '0', 'f838fba06070a82e0fd1c9eb8ce2c1a8', 'userd100', '', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `gsmcnew`
--

CREATE TABLE IF NOT EXISTS `gsmcnew` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `slogin` varchar(25) NOT NULL,
  `spassword` varchar(35) NOT NULL,
  `email` varchar(50) NOT NULL,
  `activation` int(1) NOT NULL,
  `mxdvs` varchar(40) NOT NULL,
  `btnmx` varchar(15) NOT NULL,
  `mxbtmnl` varchar(6) NOT NULL,
  `mxcount` varchar(500) NOT NULL,
  `timebtnmx` varchar(32) NOT NULL,
  `kountmx` varchar(50) NOT NULL,
  `kountttHSP` varchar(50) NOT NULL,
  `slbuymx` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `gsmcnew`
--

INSERT INTO `gsmcnew` (`id`, `slogin`, `spassword`, `email`, `activation`, `mxdvs`, `btnmx`, `mxbtmnl`, `mxcount`, `timebtnmx`, `kountmx`, `kountttHSP`, `slbuymx`) VALUES
(7, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@z-files.site', 2, '0.00000000', '', 'MINING', '', '', '', '', ''),
(10, 'userd100', 'f838fba06070a82e0fd1c9eb8ce2c1a8', 'userd100@gmail.com', 1, '0.00000000', '', 'MINING', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `gusers`
--

CREATE TABLE IF NOT EXISTS `gusers` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `glogin` varchar(20) CHARACTER SET latin1 NOT NULL,
  `gpassword` varchar(35) CHARACTER SET latin1 NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `reg_date` varchar(32) CHARACTER SET latin1 NOT NULL,
  `name_user` varchar(32) CHARACTER SET latin1 NOT NULL,
  `lastname` varchar(32) CHARACTER SET latin1 NOT NULL,
  `IP` varchar(25) CHARACTER SET latin1 NOT NULL,
  `activation` int(1) NOT NULL,
  `Cash` varchar(25) CHARACTER SET latin1 NOT NULL,
  `DVS` varchar(40) CHARACTER SET latin1 NOT NULL,
  `datewithdraw` varchar(32) CHARACTER SET latin1 NOT NULL,
  `adresswithdraw` varchar(40) CHARACTER SET latin1 NOT NULL,
  `deposit` varchar(54) CHARACTER SET latin1 NOT NULL,
  `paylabel` varchar(20) CHARACTER SET latin1 NOT NULL,
  `amountwithdraw` varchar(15) CHARACTER SET latin1 NOT NULL,
  `ldate` varchar(32) CHARACTER SET latin1 NOT NULL,
  `btnml` varchar(15) CHARACTER SET latin1 NOT NULL,
  `DVSbtmnl` varchar(6) CHARACTER SET latin1 NOT NULL,
  `countbtn` varchar(500) CHARACTER SET latin1 NOT NULL,
  `timebtnb` varchar(32) CHARACTER SET latin1 NOT NULL,
  `timebtnd` varchar(32) CHARACTER SET latin1 NOT NULL,
  `kounttt` varchar(50) CHARACTER SET latin1 NOT NULL,
  `kountdvs` varchar(50) CHARACTER SET latin1 NOT NULL,
  `pressblock` int(1) NOT NULL,
  `rulebuy` varchar(5) CHARACTER SET latin1 NOT NULL,
  `slbuydvs` varchar(25) CHARACTER SET latin1 NOT NULL,
  `flnmb` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `gusers`
--

INSERT INTO `gusers` (`id`, `glogin`, `gpassword`, `email`, `reg_date`, `name_user`, `lastname`, `IP`, `activation`, `Cash`, `DVS`, `datewithdraw`, `adresswithdraw`, `deposit`, `paylabel`, `amountwithdraw`, `ldate`, `btnml`, `DVSbtmnl`, `countbtn`, `timebtnb`, `timebtnd`, `kounttt`, `kountdvs`, `pressblock`, `rulebuy`, `slbuydvs`, `flnmb`) VALUES
(7, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@z-files.site', '15-11-2016  12:16', 'admin', 'admin', '000.000.000.00', 2, '0.00000000', '0.00000000', '', '', 'Please click on the button and generate a new address', '', '', '', 'MINING', 'MINING', '', '', '', '', '', 0, '', '', ''),
(10, 'userd100', 'f838fba06070a82e0fd1c9eb8ce2c1a8', 'userd100@gmail.com', '27-11-2017  00:44', 'userd100', 'userd100', '105.67.3.41', 1, '0.01000000', '0.00000000', '', '', 'Please click on the button and generate a new address', '', '', '27-11-2017  00:45:11', 'MINING', 'MINING', '', '', '', '', '', 0, '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `ltcdoge`
--

CREATE TABLE IF NOT EXISTS `ltcdoge` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `flogin` varchar(20) CHARACTER SET latin1 NOT NULL,
  `fpassword` varchar(35) CHARACTER SET latin1 NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `activation` int(1) NOT NULL,
  `dogedeposit` varchar(54) CHARACTER SET latin1 NOT NULL,
  `paylabeldoge` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Cashdoge` varchar(25) CHARACTER SET latin1 NOT NULL,
  `litedeposit` varchar(54) CHARACTER SET latin1 NOT NULL,
  `paylabellite` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Cashlite` varchar(25) CHARACTER SET latin1 NOT NULL,
  `pressdoge` int(1) NOT NULL,
  `presslite` int(1) NOT NULL,
  `datewithdrawd` varchar(32) CHARACTER SET latin1 NOT NULL,
  `datewithdrawl` varchar(32) CHARACTER SET latin1 NOT NULL,
  `adresswithdrawd` varchar(40) CHARACTER SET latin1 NOT NULL,
  `adresswithdrawl` varchar(40) CHARACTER SET latin1 NOT NULL,
  `amountwithdrawd` varchar(15) CHARACTER SET latin1 NOT NULL,
  `amountwithdrawl` varchar(15) CHARACTER SET latin1 NOT NULL,
  `check` varchar(4) CHARACTER SET latin1 NOT NULL,
  `hisbit` varchar(25) CHARACTER SET latin1 NOT NULL,
  `hisdoge` varchar(25) CHARACTER SET latin1 NOT NULL,
  `hislite` varchar(25) CHARACTER SET latin1 NOT NULL,
  `flnmbd` varchar(10) NOT NULL,
  `flnmbl` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `ltcdoge`
--

INSERT INTO `ltcdoge` (`id`, `flogin`, `fpassword`, `email`, `activation`, `dogedeposit`, `paylabeldoge`, `Cashdoge`, `litedeposit`, `paylabellite`, `Cashlite`, `pressdoge`, `presslite`, `datewithdrawd`, `datewithdrawl`, `adresswithdrawd`, `adresswithdrawl`, `amountwithdrawd`, `amountwithdrawl`, `check`, `hisbit`, `hisdoge`, `hislite`, `flnmbd`, `flnmbl`) VALUES
(7, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@z-files.site', 2, 'Please click on the button and generate a new address', '', '0.00000000', 'Please click on the button and generate a new address', '', '0.00000000', 0, 0, '', '', '', '', '', '', '', '0.00000000', '0.00000000', '0.00000000', '', ''),
(10, 'userd100', 'f838fba06070a82e0fd1c9eb8ce2c1a8', 'userd100@gmail.com', 1, 'Please click on the button and generate a new address', '', '1000.00000000', 'Please click on the button and generate a new address', '', '0.10000000', 0, 0, '', '', '', '', '', '', '', '0.00000000', '0.00000000', '0.00000000', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `ltcdogeming`
--

CREATE TABLE IF NOT EXISTS `ltcdogeming` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `vlogin` varchar(20) CHARACTER SET latin1 NOT NULL,
  `vpassword` varchar(35) CHARACTER SET latin1 NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `activation` int(1) NOT NULL,
  `btndoge` varchar(6) CHARACTER SET latin1 NOT NULL,
  `btnltc` varchar(6) CHARACTER SET latin1 NOT NULL,
  `btndvs` varchar(6) CHARACTER SET latin1 NOT NULL,
  `timebtndoge` varchar(32) CHARACTER SET latin1 NOT NULL,
  `timebtnltc` varchar(32) CHARACTER SET latin1 NOT NULL,
  `timebtndvs` varchar(32) CHARACTER SET latin1 NOT NULL,
  `cntdfirst` varchar(50) CHARACTER SET latin1 NOT NULL,
  `DVSm` varchar(40) CHARACTER SET latin1 NOT NULL,
  `countedc` varchar(500) CHARACTER SET latin1 NOT NULL,
  `kountttMINI` varchar(50) CHARACTER SET latin1 NOT NULL,
  `slbuydvsm` varchar(25) CHARACTER SET latin1 NOT NULL,
  `countedcl` varchar(500) NOT NULL,
  `cntdtwo` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `ltcdogeming`
--

INSERT INTO `ltcdogeming` (`id`, `vlogin`, `vpassword`, `email`, `activation`, `btndoge`, `btnltc`, `btndvs`, `timebtndoge`, `timebtnltc`, `timebtndvs`, `cntdfirst`, `DVSm`, `countedc`, `kountttMINI`, `slbuydvsm`, `countedcl`, `cntdtwo`) VALUES
(7, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@z-files.site', 2, 'MINING', 'MINING', 'MINING', '', '', '', '', '0.00000000', '', '', '', '', ''),
(10, 'userd100', 'f838fba06070a82e0fd1c9eb8ce2c1a8', 'userd100@gmail.com', 1, 'MINING', 'MINING', 'MINING', '', '', '', '', '0.00300000', '', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
