<?Php include_once("bd.php"); ?>
<?Php
$DBmyday = mysql_query("SELECT daycash, daycashdoge, daycashlite, countref FROM greffer WHERE rlogin='$login'AND rrpassword='$password' AND activation='1' ");
$ReMy = mysql_fetch_array($DBmyday) or die(mysql_error());
$ReRenk = $ReMy['daycash'];
//---------
$DBrule = mysql_query("SELECT rulebuy FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arRULE = mysql_fetch_array($DBrule) or die(mysql_error());
$SRULE=$arRULE['rulebuy'];
//---------
$ReRenkdoge = $ReMy['daycashdoge'];
$ReRenklite = $ReMy['daycashlite'];
$ReCountWin = $ReMy['countref'];
if ($ReRenk !=0) {
$testtest = "";
}
if ($ReRenkdoge !=0) {
$testtestdoge = "";
}
if ($ReRenklite !=0) {
$testtestlite = "";
}
if ($ReCountWin == 101) {
$testwinwin = "";
}
if ($SRULE == "false") {
$testbuy = "";
mysql_query("UPDATE gusers SET rulebuy = 'true' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");
}
?>