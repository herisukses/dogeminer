<!DOCTYPE HTML>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
		<title>TCC</title>
        
        <link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
<link rel="stylesheet" href="assets/faq22.css" />

	</head>
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1 id="logo"><a href="/">TCC<span> Cloud mining cryptocurrency</span></a></h1>
					<nav id="nav">
						<ul>
							<li class="submenu">
								<a href="#">Menu</a>
								<ul>
								   <li><a href="/">Main</a></li>
                                   <li><a href="faq.html">Faq</a></li>
                                   <li><a href="support.php">Support</a></li>
								</ul>
							</li>
<li class="submenu">
								<a href="#">language</a>
								<ul>
									<li><a href="/">English</a></li>
									<li><a href="http://translate.google.com/translate?sl=en&tl=fr&u=http%3A%2F%2Fdemo2.cryptodesign.xyz">French</a></li>
									<li><a href="http://translate.google.com/translate?sl=en&tl=nl&u=http%3A%2F%2Fdemo2.cryptodesign.xyz">deutsch</a></li>
                                    <li><a href="http://translate.google.com/translate?sl=en&tl=zh-CN&u=http%3A%2F%2Fdemo2.cryptodesign.xyz">中文</a></li>
                                    <li><a href="http://translate.google.com/translate?sl=en&tl=ru&u=http%3A%2F%2Fdemo2.cryptodesign.xyz">Россия</a></li>
								</ul>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">

					<!--
						".inner" is set up as an inline-block so it automatically expands
						in both directions to fit whatever's inside it. This means it won't
						automatically wrap lines, so be sure to use line breaks where
						appropriate (<br />).
					-->
					<div class="inner">

						<header>
							<h2>TCC mining</h2>
						</header>
                        <h1>News</h1>
						<footer>

						</footer>
					</div>

				</section>

			<!-- Main -->
				<article id="main">
                 
					<header class="special container">
						<span class="icon fa-rss"></span>
						<h2>Actual events taking place on the site</h2>
					</header>
                                <p><a name="pack"></a></p>
                                    <section class="wrapper style3 container special">
                                    <img src="images/pammportfel.png" alt="" />
                    <li>30-01-2017   We suggest you to invest in equipment for mining Dogecoin.
Attachments will be accepted until 01.03.2017.</li>
                    <li>The number of packages is limited to 1000. Minimum purchase 1 pack. </li>
                    <li>Starting a new farm 10/03/2017
Investors allocated 1,000 packages.</li>
<li>After running the farm 10.03.2017 you will receive 50% of mining on the new equipment according to the number of packages purchased.
50% of each package gets company TCC.</li><br><br>
                  <li>30-01-2017  我們建議您投資設備挖掘Dogecoin。
附件將被接受，直到01年03月02日.</li>
                    <li>
包的數量限制為1000.最低購買1包。 </li>
                    <li>開始新農場10/11/2017
投資者分配1000包。</li>
<li>運行農場10.03.2017後，您將根據購買的包裹數量，在新設備上獲得50％的採礦。
50％的每個包得到公司 TCC.</li><br><br>
                    <li>30-01-2017   Мы предлагаем вам инвестировать в оборудование для добычи Dogecoin.
Вложения будут приниматься до 11.11.2017.</li>
                    <li>Число пакетов ограничено 1000. Минимальная покупка 1 пакета. </li>
                    <li>Запуск новой фермы 10/03/2017
Инвесторы выделено 1000 пакетов.</li>
<li>После запуска фермы 10.11.2017 вы будете получать 50% от добычи на новом оборудовании в соответствии с количеством пакетов, приобретенных.
50% каждого пакета получает компанию TCC.</li><br><br>
                       <footer class="major">

							</footer>

						</section>
											            <section class="wrapper style3 container special">
                    <li>29-10-2017  Due to the heavy load on the Bitcoin network is the minimum deposit 0.005 Btc </li>
                       <footer class="major">

							</footer>

						</section>	
							            <section class="wrapper style3 container special">
                    <li>15-10-2017  For technical problems temporarily disabled the generation of Bitcoin addresses </li>
                       <footer class="major">

							</footer>

						</section>	
                    <p><a name="promo"></a></p>
                                    <section class="wrapper style3 container special">
                    <li>11-10-2017   From December 11 to January 2, buy <strong Style=" background: #99CCFF;">2</strong> Hash-700mx and get <strong Style=" background: #FF3300; font-size: xx-large; color: #FFFFFF;">1.5</strong> Hash-500m free. <img src="images/Promo.png" alt="" /></li>
                    <li>After purchase you will receive a promo code.</li>
                       <footer class="major">

							</footer>

						</section>
					            <section class="wrapper style3 container special">
                    <li>08-10-2017  Now, the minimum deposit amount: 0.001 BTC, 100 Doge, 0.1 LTC </li>
                       <footer class="major">

							</footer>

						</section>
                                 <section class="wrapper style3 container special">
                    <li>07-10-2017  Now you can buy cloud Hash-300m for bitcoin  </li>
                       <footer class="major">

							</footer>

						</section>
                              <section class="wrapper style3 container special">
                    <li>06-10-2017  Now you can buy a cloud  Hash-500m for bitcoin  </li>
                       <footer class="major">

							</footer>

						</section>
                                  <section class="wrapper style3 container special">
                    <li>03-10-2017  Temporarily disabled buying cloud hash-500m and hash-300m for Bitcoin </li>
                       <footer class="major">

							</footer>

						</section>
                               <section class="wrapper style3 container special">
                    <li>02-10-2017  Changed referral system. Сharging now occur every day at a rate of 4% on the currency that produces your referral. </li>
                       <footer class="major">

							</footer>

						</section>
                    <section class="wrapper style3 container special">
                    <li>01-10-2017  TCC cloud mining START </li>
                       <footer class="major">

							</footer>

						</section>
				</article>

			<!-- Footer -->
				<footer id="footer">

					<div class="container">
<div class="menu" style="padding-left:200px;">
<div class="row">



<div class="col-sm-3 col-xs-6">
<div class="header">
<u><b>Contacts</u></b> </div>
<ul class="list-unstyled">
<li>
<a href="mailto:admin@mail.com">admin@mail.com</a>
</li>
<li>
+00 001 001 0001
</li>
<li>
Kartin B45 ,UK
</li>
<li>
<a href="#">Google Maps</a>
</li>
</ul>
</div>



<div class="col-sm-3 col-xs-6">
<div class="header">
<b><u>We support</u></b> </div>
<ul class="list-unstyled">
<img src="/images/DLB.png" alt="Comodo">

</ul>
</div>
<div class="col-sm-3 col-xs-6">
<div class="header">
<b><u>Follow us</u></b> </div>
<ul class="list-unstyled">
<li>
<a href="#" rel="nofollow"><i class="fa fa-facebook-square" aria-hidden="true"></i>
 Facebook</a>
</li>
<li>
<a href="#" rel="nofollow"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
</li>
<li>
<a href="#" rel="nofollow"><i class="fa fa-google-plus-square" aria-hidden="true"></i> Google+</a>
</li><li>
<a href="#" rel="nofollow"><i class="fa fa-youtube-square" aria-hidden="true"></i> Youtube</a>
</li>
</ul>
</div>

</div>
</div>

<div class="copyright">
<p>&copy; 2017 <a href="/">TCC</a> All Rights Reserved.</p></div>
<img src="/images/ssl.png" alt="Comodo">

				</footer>

		</div>

		<!-- Scripts -->
             <script>
               function look(type){
                param=document.getElementById(type);
                if(param.style.display == "none") param.style.display = "block";
                else param.style.display = "none"
             }
            </script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
		

	</body>
</html>