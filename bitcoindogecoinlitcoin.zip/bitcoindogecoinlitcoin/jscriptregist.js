var min_length=6;
function passValid(form,password,pass12,submit)
{
  PASS12=document.getElementById(pass12);
  PASS1count=document.forms[form].password.value.length;
  MARG_LEFT= 10*PASS1count-100;
  if(MARG_LEFT<0)
  {
  PASS12.style.marginLeft=MARG_LEFT+"px";
  }
  if(MARG_LEFT>=0)
  {
  	PASS12.style.marginLeft="0px";
  }
  if(PASS1count<4){PASS12.style.background="#f00";}
  else if((PASS1count>=4) && (PASS1count<6)){PASS12.style.background="#FF9F00";}
  else if((PASS1count>=6) && (PASS1count<8)){PASS12.style.background="#CBFE01";}
  else if((PASS1count>=8)){PASS12.style.background="#0EFE01";}

}


