<?php
ini_set('display_errors', 0);
error_reporting(0);
include_once("bd.php");
if(empty($login) and empty($password)){
require("main.html");
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>TCC</title>
  	<link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
      <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
    <style type="text/css">
<!--
.�����2 {color: #008800}
.�����3 {color: #110000}
-->
    </style>
<body class="hold-transition skin-blue sidebar-mini">
<?php
$DBCash = mysql_query("SELECT Cash FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$DBLtcDoge = mysql_query("SELECT Cashdoge, Cashlite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$array = mysql_fetch_array($DBCash);
$arrayCdoge = mysql_fetch_array($DBLtcDoge);
$arrayCF = $array['Cash'];
$CashDoge = $arrayCdoge['Cashdoge'];
$CashLite = $arrayCdoge['Cashlite'];
$arrayCVF = number_format($arrayCF, 8, '.', '');
$CashDogeF = number_format($CashDoge, 8, '.','');
$CashLiteF = number_format($CashLite, 8, '.','');
$currency = "USD";
$exchange_query_result = file_get_contents('https://blockchain.info/ru/ticker');
$exchange_data_obj = json_decode($exchange_query_result);
$KURS= "USD in BTC: ".$exchange_data_obj->$currency->last;
//-----------------------------------------------------------
$DBRATE = mysql_query("SELECT usdinbtc, dogeusd, ltcusd, dogebtc, ltcbtc FROM costsmc WHERE id='1' ");
$arrayRATE = mysql_fetch_array($DBRATE);
$usdinbtc = $arrayRATE['usdinbtc'];
$dogeusd = $arrayRATE['dogeusd'];
$ltcusd = $arrayRATE['ltcusd'];
$dogebtc = $arrayRATE['dogebtc'];
$ltcbtc = $arrayRATE['ltcbtc'];
?>
<?Php
$DBHist = mysql_query("SELECT reg_date FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayHistory = mysql_fetch_array($DBHist) or die(mysql_error());
$ArrDatereg = $arrayHistory['reg_date'];
?>
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>T</b>CC</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>TCC</b> mining</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu" style="text-align: center; list-style:none; padding-top: 10px;background:#333;">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
             
              <span class="label label-success" ><i class="fa fa-spinner" aria-hidden="true"></i>Actual Exchange Rates</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"></li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="background:#333;font-weight: bold;text-align:center;">
                   <li>
                      <b>
                       <?Php echo " 1 BTC = ".$usdinbtc ; ?>
                        <small><i class="fa fa-usd"></i></small>
                      </b>
                  </li>
                  <li>
                       
                       <?Php echo " 1 LTC = ".$ltcusd; ?>
                        <small><i class="fa fa-usd"></i></small>
                       
                  </li>
                  <li>
                       
                        <?Php echo " 1 DOGE = ".$dogeusd; ?>
                        <small><i class="fa fa-usd"></i></small>
                       
                  </li>
<li><?Php echo " BTC in DOGE: ".$dogebtc; ?></li>
<li><?Php echo " BTC in LTC: ".$ltcbtc; ?></li>

                </ul>
              </li>
            </ul>
          </li>




          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu" style="padding-left: 20px;padding-top: 10px;">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="label label-default" ><i class="fa fa-usd"></i>Balance</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"></li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="background:#333;font-weight: bold;text-align:center;">
                <h4>
                  <li>
                      <i><img src="images/lb1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$arrayCVF; ?></i><b> BTC</b>
                  </li>
                  <li>
                     <i><img src="images/ll1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashLiteF; ?></i> LTC
                  </li>
                  <li>
                      <i><img src="images/ld1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashDogeF; ?></i> DOGE
                  </li>
                  </h4>
                </ul>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">

              <span class="label label-default" ><i class="fa fa-user" aria-hidden="true"></i>
</span>
            </a>
            <ul class="dropdown-menu" style="background:#333;">
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="profile.php" class="btn btn-default btn-flat">Account</a>
                </div>
                <div class="pull-right">
                  <a href="exit.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar" class="label label-default" style="background: #2e2e2e;" ><i class="fa fa-arrow-down"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <li class="treeview">
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="buycloud.php">
            <i class="fa fa-cloud"></i>
            <span>Clouds</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="buycloud.php#h500"><i class="fa fa-circle-o text-red"></i> <span>HASH-500m</span></a></li>
            <li><a href="buycloud.php#h300"><i class="fa fa-circle-o text-purple"></i> <span>HASH-300m</span></a></li>
            <li><a href="buycloud.php#h700"><i class="fa fa-circle-o text-aqua"></i> <span>HASH-700mx</span></a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-plus"></i>
            <span>Deposit</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="deposit.php#hdbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="deposit.php#hdlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="deposit.php#hddoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-minus"></i> <span>Withdraw</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="withdraw.php#hbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="withdraw.php#hlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="withdraw.php#hdoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
        <li>
          <a href="profile.php">
            <i class="fa fa-user"></i> <span>Account</span>
          </a>
        </li>
        <li class="active treeview">
          <a href="history.php">
            <i class="fa fa-book"></i> <span>History</span>
          </a>
        </li>
        <li class="treeview">
          <a href="exit.php">
            <i class="fa fa-power-off"></i> <span>Signout</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        History
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-cloud"></i> Home</a></li>
        <li class="active">History</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
        <p>
				<div id="depositar">
		<div align="center">Registration Date: <?Php echo $ArrDatereg; ?></div>
				<iframe src="historyinc.php" width="100%" height="600"   frameborder="0" style="border: 2px solid #83D3C9; border-radius: 20px;"></iframe>
		  </div>
				  </p>
    </div>
  </div>
  </section>
  <footer class="main-footer" style="background:#333;color:white;">
    <strong>Copyright &copy; 2017 <a href="/">TCC</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-arrow-down"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">TCC</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="faq.html">
              <i class="menu-icon fa fa-mortar-board bg-red"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">FAQ</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="news.php">
              <i class="menu-icon fa fa-newspaper-o bg-yellow"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">NEWS</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="support.php">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">SUPPORT</h4>
              </div>
            </a>
          </li>
        </ul>
        </div>
        </div>
  </aside>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
</body>
</html>