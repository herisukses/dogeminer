<?Php
ini_set('display_errors', 1);
error_reporting(1);
include_once("bd.php");
include_once("index.php");
include_once("incminingltcdog.php");
include_once("initsmc.php");
include_once("intmining.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>TCC</title>
  <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  	<link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
     	    <style type="text/css">
<!--
#lrpictor {
	width:100%;
	height:121px;
	z-index:54;
}
#Lr12 {
    display: block;
	position:fixed;
	width:100%;
	height:60%;
	bottom: 300px;
	left: 0px;
	top: 0px;
	background-image: url(../../images/fofn.png);
    background-repeat: repeat;
}
@media only screen and ( max-width: 767px) {
#labelcounted{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#labelcounted{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#labellite{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#labellite{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#labeldoge{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#labeldoge{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#labeldvsm{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#labeldvsm{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#labeldhsp{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#labeldhsp{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#labelDVS{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#labelDVS{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#tableOUR{
font-size:7px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#tableOUR{
font-size:7px;
}
}
-->
    </style>
    <style type="text/css">
#divtest{
    font-size: 18px;
    background-color: #83D3C9;
}
#divtestdoge{
    font-size: 18px;
    background-color: #83D3C9;
}
#divtestlite{
    font-size: 18px;
    background-color: #83D3C9;
}
#divwinwin {
    font-size: 18px;
    background-color: #83D3C9;
}
</style>
<style>
form.frmrefconf{
    border: 3px solid #FF4242;
}
form.frmrefconfd{
    border: 3px solid #FF4242;
}
form.frmrefconfl{
    border: 3px solid #FF4242;
}
form.frmwinwin{
    border: 3px solid #FF4242;
}
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php
$testtest = "display:none";
$testtestdoge = "display:none";
$testtestlite = "display:none";
$testwinwin =  "display:none";
$testbuy = "display:none";
$DBCash = mysql_query("SELECT Cash FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$DBLtcDoge = mysql_query("SELECT Cashdoge, Cashlite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$array = mysql_fetch_array($DBCash);
$arrayCdoge = mysql_fetch_array($DBLtcDoge);
$arrayCF = $array['Cash'];
$CashDoge = $arrayCdoge['Cashdoge'];
$CashLite = $arrayCdoge['Cashlite'];
$arrayCVF = number_format($arrayCF, 8, '.', '');
$CashDogeF = number_format($CashDoge, 8, '.','');
$CashLiteF = number_format($CashLite, 8, '.','');
$currency = "USD";
$exchange_query_result = file_get_contents('https://blockchain.info/ru/ticker');
$exchange_data_obj = json_decode($exchange_query_result);
$KURS= "USD in BTC: ".$exchange_data_obj->$currency->last;
//-----------------------------------------------------------
$DBRATE = mysql_query("SELECT usdinbtc, dogeusd, ltcusd, dogebtc, ltcbtc FROM costsmc WHERE id='1' ");
$arrayRATE = mysql_fetch_array($DBRATE);
$usdinbtc = $arrayRATE['usdinbtc'];
$dogeusd = $arrayRATE['dogeusd'];
$ltcusd = $arrayRATE['ltcusd'];
$dogebtc = $arrayRATE['dogebtc'];
$ltcbtc = $arrayRATE['ltcbtc'];
?>
<?Php
$PerDayDash = ($LBCAshD / 30);
$PerHourDash = ($PerDayDash / 24);
$PerYearDash = ($LBCAshD * 12);
$PerThreeDash = ($PerYearDash *3);
//- - - - - - - - - - - - - - - - -
$PerHourDashN = number_format($PerHourDash,8,'.','');
$PerDayDashN = number_format($PerDayDash,8,'.','');
$PerMonthDashN = number_format($LBCAshD,8,'.','');
$PerYearDashN = number_format($PerYearDash,8,'.','');
$PerThreeDashN = number_format($PerThreeDash,8,'.','');
?>
<?Php
$MiniCountD= (($DVSMini* $PriceDogeNF)/3.2);
$PerDayDoge = ($MiniCountD /30);
$PerHourDoge = ($PerDayDoge / 24);
$PerYearDoge = ($MiniCountD * 12);
$PerThreeDoge = ($PerYearDoge * 3);
$PerHourDogeN = number_format($PerHourDoge,8,'.','');
$PerDayDogeN = number_format($PerDayDoge,8,'.','');
$PerMonthDogeN = number_format($MiniCountD,8,'.','');
$PerYearDogeN = number_format($PerYearDoge,8,'.','');
$PerThreeDogeN = number_format($PerThreeDoge,8,'.','');
//-------------------------------------------------------
$MiniCountL= (($DVSMini* $PriceLtcNF)/3.2);
$PerDayLite = ($MiniCountL /30);
$PerHourLite = ($PerDayLite / 24);
$PerYearLite = ($MiniCountL * 12);
$PerThreeLite = ($PerYearLite *3);
$PerHourLiteN = number_format($PerHourLite,8,'.','');
$PerDayLiteN = number_format($PerDayLite,8,'.','');
$PerMonthLiteN = number_format($MiniCountL,8,'.','');
$PerYearLiteN = number_format($PerYearLite,8,'.','');
$PerThreeLiteN = number_format($PerThreeLite,8,'.','');
?>
<?Php
include_once("percent.php");
$WiRERE = mysql_query("SELECT id FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$WiREFRE = mysql_fetch_array($WiRERE) or die(mysql_error());
$WiNRE = $WiREFRE['id'];
$WiREmdl = md5($WiNRE);
$WiNADRRE = $WiREmdl.".txt";
$WiARFE = './histor/'.$WiNADRRE;
if  (isset($_POST['btnOkref'])) {
$DBMyCash = mysql_query("SELECT Cash FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayMyCash = mysql_fetch_array($DBMyCash) or die(mysql_error());
$SummaREfCash=$arrayMyCash['Cash'];
$OurSumMy = ($SummaREfCash + $ReRenk);
//----------------------------------------------------------------------
$bbitdate = date("d-m-Y  H:i");
$textbit = $bbitdate." - "." referral bonus"." ".$ReRenk." BTC".'<br>';
//----------------------------------------------------------------------
  $text_bit=file_get_contents($WiARFE);
  $fdbit=$textbit.$text_bit;
  $f_outbit = fopen($WiARFE,"w");
  fwrite($f_outbit, $fdbit);
  fclose($f_outbit);
//----------------------------------------------------------------------
mysql_query("UPDATE gusers SET Cash = '$OurSumMy' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");
mysql_query("UPDATE greffer SET daycash = '0' WHERE rlogin='$login'AND rrpassword='$password' AND activation='1' ");
header('Location:index.php');
}
//--------
if  (isset($_POST['btnOkrefd'])) {
$DBMyCashdoge = mysql_query("SELECT Cashdoge FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrayMyCashdoge = mysql_fetch_array($DBMyCashdoge) or die(mysql_error());
$SummaREfDOGE=$arrayMyCashdoge['Cashdoge'];
$OurSumMyD = ($SummaREfDOGE + $ReRenkdoge);
//----------------------------------------------------------------------
$ddogedate = date("d-m-Y  H:i");
$textdoge = $ddogedate." - "." referral bonus"." ".$ReRenkdoge." DOGE".'<br>';
//----------------------------------------------------------------------
  $text_doge=file_get_contents($WiARFE);
  $fddoge=$textdoge.$text_doge;
  $f_outdoge = fopen($WiARFE,"w");
  fwrite($f_outdoge, $fddoge);
  fclose($f_outdoge);
//----------------------------------------------------------------------
mysql_query("UPDATE ltcdoge SET Cashdoge = '$OurSumMyD' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");
mysql_query("UPDATE greffer SET daycashdoge = '0' WHERE rlogin='$login'AND rrpassword='$password' AND activation='1' ");
 header('Location:index.php');
}
//-----
if  (isset($_POST['btnOkrefl'])) {
$DBMyCashlite = mysql_query("SELECT Cashlite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrayMyCashlite = mysql_fetch_array($DBMyCashlite) or die(mysql_error());
$SummaREfLite=$arrayMyCashlite['Cashlite'];
$OurSumMyL = ($SummaREfLite + $ReRenklite);
//----------------------------------------------------------------------
$llitedate = date("d-m-Y  H:i");
$textlite = $llitedate." - "." referral bonus"." ".$ReRenklite." LTC".'<br>';
//----------------------------------------------------------------------
  $text_lite=file_get_contents($WiARFE);
  $fdlite=$textlite.$text_lite;
  $f_outlite = fopen($WiARFE,"w");
  fwrite($f_outlite, $fdlite);
  fclose($f_outlite);
//----------------------------------------------------------------------
mysql_query("UPDATE ltcdoge SET Cashlite = '$OurSumMyL' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");
mysql_query("UPDATE greffer SET daycashlite = '0' WHERE rlogin='$login'AND rrpassword='$password' AND activation='1' ");
 header('Location:index.php');
}
//-----
if  (isset($_POST['btnOkwin'])) {
if ($ReCountWin == 101):
$ReWIN = "0.02400000";
$DBCashWIN = mysql_query("SELECT Cash FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arWINWIN = mysql_fetch_array($DBCashWIN) or die(mysql_error());
$SummaWIN=$arWINWIN['Cash'];
$OurSumWIN = ($SummaWIN + $ReWIN);
$OurSumWINN = number_format($OurSumWIN,8,'.','');
//----------------------------------------------------------------------
$WINMYdate = date("d-m-Y  H:i");
$textWINWIN = $WINMYdate." - "." Bonus for 100 referrals"." "." 0.02400000"." BTC".'<br>';
//----------------------------------------------------------------------
  $text_winwin=file_get_contents($WiARFE);
  $fdWIN=$textWINWIN.$text_winwin;
  $f_outWIN = fopen($WiARFE,"w");
  fwrite($f_outWIN, $fdWIN);
  fclose($f_outWIN);
//----------------------------------------------------------------------
mysql_query("UPDATE gusers SET Cash = '$OurSumWINN' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");
mysql_query("UPDATE greffer SET countref = '0' WHERE rlogin='$login'AND rrpassword='$password' AND activation='1' ");
 header('Location:index.php');
 endif;
if ($ReCountWin != 101):
echo "error";
endif;
}
?>
  	<script>
function look(type){
param=document.getElementById(type);
if(param.style.display == "none") param.style.display = "block";
else param.style.display = "none"
}
</script>

        <form id="form9" name="form9" method="post" action="" hidden disabled>
        <label>
        <input name="txtSecunda" type="text" id="txtSecunda" value="<?Php echo $xCountedB; ?>" hidden />
        </label>
        </form>
        <form id="form4" name="form4" method="post" action="" hidden>
          <label>
            <input name="txtTime" type="text" id="txtTime" value="<?Php echo $tmbdtm; ?>" hidden />
          </label>
        </form>

        <form id="form2" name="form2" method="post" action="" hidden>
          <label>
            <input name="earn_month" type="text" id="earn_month" value="<?Php  echo $intspeedL=number_format($BITOURINI,11,'.','');  ?>" hidden />
          </label>
        </form>
		 <form id="form3" name="form3" method="post" action="" hidden>
          <label>
            <input name="txtsum" type="text" id="txtsum" value="<?Php echo $CountebtnF = number_format($xCountedB,11,'.',''); ?>" hidden />
		   </label>
	    </form>
			<form id="form13" name="form13" method="post" action="" hidden>
          <label>
            <input name="txtSumDVS" type="text" id="txtSumDVS" value="<?php echo $CountedDVSum = number_format($xCountedBDVS,11,'.',''); ?>" hidden />
          </label>
	    </form>
		  <form id="formDVS" name="formDVS" method="post" action="" hidden>
          <label>
          <input name="earn_montt" type="text" id="earn_montt" value="<?php echo  $intspeedDVS = number_format (($DVST/2.9), 11,'.','');?>" hidden />
          </label>
		  </form>
          <form id="form6" name="form6" method="post" action="" hidden>
            <label>
            <input name="earn_doge" type="text" id="earn_doge" value="<?Php  echo $intspeedLDOGE=number_format($OURDGDG,11,'.','');  ?>"  hidden />
            </label>
        </form>
          <form id="form7" name="form7" method="post" action="" hidden>
            <label>
            <input name="txtDogeSum" type="text" id="txtDogeSum" value="<?Php echo $CoudogeF = number_format($xCountedBDoge,11,'.',''); ?>"  hidden/>
            </label>
        </form>
          <form id="form8" name="form8" method="post" action="" hidden>
            <label>
            <input name="earn_lite" type="text" id="earn_lite" value="<?Php  echo $intspeedLLite=number_format($OURLTCc,11,'.','');  ?>" hidden/>
            </label>
        </form>
          <form id="form10" name="form10" method="post" action="" hidden>
            <label>
            <input name="txtLiteSum" type="text" id="txtLiteSum" value="<?Php echo $CouliteF = number_format($xCountedBLite,11,'.',''); ?>" hidden/>
            </label>
        </form>
          <form id="form11" name="form11" method="post" action="" hidden>
            <label>
            <input name="earn_dvsm" type="text" id="earn_dvsm" value="<?php echo  $intdDVSm = number_format (($DVSMini/3.2), 11,'.','');?>" hidden/>
            </label>
        </form>
        <form id="form112" name="form112" method="post" action="" hidden>
            <label>
            <input name="earn_dhsp" type="text" id="earn_dhsp" value="<?php echo  $intdDHsp = number_format (($CntMXC/3.1), 11,'.','');?>" hidden/>
            </label>
        </form>
          <form id="form14" name="form14" method="post" action="" hidden>
            <label>
            <input name="txtSumDvsm" type="text" id="txtSumDvsm" value="<?php echo $CounDVSmSum = number_format($xCountedBDVSMINI,11,'.',''); ?>" hidden />
            </label>
          </form>
          <form id="form144" name="form144" method="post" action="" hidden>
            <label>
            <input name="txtSumDHSP" type="text" id="txtSumDHSP" value="<?php echo $CounDVSmSumHSP = number_format($xCountedBDVSHSP,11,'.',''); ?>" hidden />
            </label>
          </form>
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>T</b>CC</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>TCC</b> mining</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
            <a href="javascript:look('Lr12');"></a>
<div id="Lr12" style="<?Php echo $testbuy; ?>">
      <h2 class="btn-danger"><img src="images/ukflag.png" width="75" height="44" />Please stop mining before buying clouds. Press STOP and return to the buy menu.</h2>
      <h2 class="btn-danger"><img src="images/chflag.png" width="75" height="44" />请在买云之前停止采矿。按STOP并返回购买菜单。</h2>
	  	 <p align="center"><input type="submit" value="OK" name="submit" onClick="javascript:look('Lr12');" style="background-color:transparent; color:#FFFAF5; font-family:Arial, Helvetica, sans-serif; font-size:18px; border-radius: 10px; cursor: pointer;" title="OK"   >
	 </p>
      <h2 class="btn-danger"><img src="images/ruflag.png" width="75" height="44" />Пожалуйста остановите майнинг перед покупкой облака. Нажмите на STOP и вернитесь в меню покупки.</h2>
      <h2 class="btn-danger"><img src="images/geflag.png" width="75" height="44" />Bitte stoppen Bergbau vor Wolken kaufen. Drucken Sie STOP und Ruckkehr zum Kauf Menu.</h2>
      <h2 class="btn-danger"><img src="images/phflag.png" width="75" height="44" />Proszę przestać górnictwo przed zakupem chmury. Naciśnij przycisk STOP i powrócić do menu kupna.</h2>
</div>
         <a href="javascript:look('divtest');"></a>
	<div id="divtest" style="<?Php echo $testtest; ?>">
      <div align="center"><?Php echo "You have received a referral bonus "." + ".$ReRenk." BTC"; ?></div><br>
       <div align="center">
       	<form class="frmrefconf" method="post" name="frmrefconf" id="frmrefconf">
          <input name="btnOkref" type="submit" id="btnOKref" value="OK" style="background-color:transparent; cursor: pointer;" title="OK">
        </form>
        </div>
       <br>
	</div>
            <a href="javascript:look('divtestdoge');"></a>
	<div id="divtestdoge" style="<?Php echo $testtestdoge; ?>">
      <div align="center"><?Php echo "You have received a referral bonus "." + ".$ReRenkdoge." DOGE"; ?></div><br>
       <div align="center">
       	<form class="frmrefconfd" method="post" name="frmrefconfd" id="frmrefconfd">
          <input name="btnOkrefd" type="submit" id="btnOKrefd" value="OK" style="background-color:transparent; cursor: pointer;" title="OK">
        </form>
        </div>
       <br>
	</div>
            <a href="javascript:look('divtestlite');"></a>
	<div id="divtestlite" style="<?Php echo $testtestlite; ?>">
      <div align="center"><?Php echo "You have received a referral bonus "." + ".$ReRenklite." LTC"; ?></div><br>
       <div align="center">
       	<form class="frmrefconfl" method="post" name="frmrefconfl" id="frmrefconfl">
          <input name="btnOkrefl" type="submit" id="btnOKrefl" value="OK" style="background-color:transparent; cursor: pointer;" title="OK">
        </form>
        </div>
       <br>
	</div>
            <a href="javascript:look('divwinwin');"></a>
	<div id="divwinwin" style="<?Php echo $testwinwin; ?>">
      <div align="center"><?Php echo "Bonus for 100 referrals "." + "." 0.02400000 !!!!!"." BTC"; ?></div><br>
       <div align="center">
       	<form class="frmwinwin" method="post" name="frmwinwin" id="frmwinwin">
          <input name="btnOkwin" type="submit" id="btnOKwin" value="OK" style="background-color:transparent; cursor: pointer;" title="OK">
        </form>
        </div>
       <br>
	</div>
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          



<li class="dropdown messages-menu" style="text-align: center; list-style:none; padding-top: 10px;background:#333;">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
             
              <span class="label label-success" ><i class="fa fa-spinner" aria-hidden="true"></i>Actual Exchange Rates</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"></li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="background:#333;font-weight: bold;text-align:center;">
                   <li>
                      <b>
                       <?Php echo " 1 BTC = ".$usdinbtc ; ?>
                        <small><i class="fa fa-usd"></i></small>
                      </b>
                  </li>
                  <li>
                       
                       <?Php echo " 1 LTC = ".$ltcusd; ?>
                        <small><i class="fa fa-usd"></i></small>
                       
                  </li>
                  <li>
                       
                        <?Php echo " 1 DOGE = ".$dogeusd; ?>
                        <small><i class="fa fa-usd"></i></small>
                       
                  </li>
<li><?Php echo " BTC in DOGE: ".$dogebtc; ?></li>
<li><?Php echo " BTC in LTC: ".$ltcbtc; ?></li>

                </ul>
              </li>
            </ul>
          </li>




          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu" style="padding-left: 20px;padding-top: 10px;">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="label label-default" ><i class="fa fa-usd"></i>Balance</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"></li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="background:#333;font-weight: bold;text-align:center;">
                <h4>
                  <li>
                      <i><img src="images/lb1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$arrayCVF; ?></i><b> BTC</b>
                  </li>
                  <li>
                     <i><img src="images/ll1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashLiteF; ?></i> LTC
                  </li>
                  <li>
                      <i><img src="images/ld1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashDogeF; ?></i> DOGE
                  </li>
                  </h4>
                </ul>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">

              <span class="label label-default" ><i class="fa fa-user" aria-hidden="true"></i>
</span>
            </a>
            <ul class="dropdown-menu" style="background:#333;">
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="profile.php" class="btn btn-default btn-flat">Account</a>
                </div>
                <div class="pull-right">
                  <a href="exit.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar" class="label label-default" style="background: #2e2e2e;" ><i class="fa fa-arrow-down"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">



</li>
        <li class="active treeview">
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-cloud"></i>
            <span>Clouds</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="buycloud.php#h500"><i class="fa fa-circle-o text-red"></i> <span>HASH-500m</span></a></li>
            <li><a href="buycloud.php#h300"><i class="fa fa-circle-o text-purple"></i> <span>HASH-300m</span></a></li>
            <li><a href="buycloud.php#h700"><i class="fa fa-circle-o text-aqua"></i> <span>HASH-700mx</span></a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-plus"></i>
            <span>Deposit</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="deposit.php#hdbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="deposit.php#hdlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="deposit.php#hddoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-minus"></i> <span>Withdraw</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="withdraw.php#hbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="withdraw.php#hlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="withdraw.php#hdoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
        <li>
          <a href="profile.php">
            <i class="fa fa-user"></i> <span>Account</span>
          </a>
        </li>
           <li>
          <a href="history.php">
            <i class="fa fa-book"></i> <span>History</span>
          </a>
        </li>
        <li class="treeview">
          <a href="exit.php">
            <i class="fa fa-power-off"></i> <span>Signout</span>
          </a>
        </li>
      </ul>




    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard

      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
      <div class="col-lg-4 goright">
				<p><a href="faq.html#minclr"><i class="fa fa-share"></i> Help me... </a></p>
			</div>
    </section>
<br/><br/>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">


<div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box " style="background:#333;">
            <div class="inner">
              <h4><div id="labelDVS"><?Php echo $DVST; ?></div></h4>

              <p>HASH-700mx</p>
            </div>
            <div class="icon">
              <i class="ion ion-cloud" style="color:#00a3cb ;"></i>
            </div>
             <div align="center" class="small-box-footer">
            <form id="formMX" name="formMX" method="post" action="">
            <input type="submit"  id="subMining2" name="subMining2" value="<?Php echo $BtmnDVS = $arrayDVSbtmnl['DVSbtmnl']; ?>" Style=" background-color: transparent; border-radius: 10px;"/>  <i class="fa fa-cloud-upload"></i>
             </form>
            </div>
          </div>
        </div>
          <!-- ./col -->
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box" style="background:#333;">
            <div class="inner">
              <h4><div id="labeldhsp"><?Php echo $CntMXC;  ?></div></h4>

              <p>HASH-300m</p>
            </div>
            <div class="icon">
              <i class="ion ion-cloud" style="color:#514e8f;"></i>
            </div>
            <div align="center" class="small-box-footer">
             <form id="form12" name="form12" method="post" action="">
            <input type="submit" id="subMining6" name="subMining6" value="<?Php echo $BtmnMX = $arrayMXBUT['mxbtmnl']; ?>" Style=" background-color: transparent; border-radius: 10px;"/>  <i class="fa fa-cloud-upload"></i>
             </form>
            </div>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box" style="background:#333;">
            <div class="inner">
              <h4><div id="labeldvsm"><?Php echo $DVSMini; ?></div></h4>

              <p>HASH-500m</p>
            </div>
            <div class="icon">
              <i class="ion ion-cloud" style="color:#bc3f30;"></i>
            </div>
            <div align="center" class="small-box-footer">
             <form id="frmMingMini" name="frmMingMini" method="post" action="">
            <input type="submit" id="subMining5" name="subMining5" value="<?Php echo $BtnDvs = $arraybutt['btndvs']; ?>" Style=" background-color: transparent; border-radius: 10px;"/>  <i class="fa fa-cloud-upload"></i>
            </form>
            </div>
          </div>
        </div>


        <!-- ./col -->
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box " style="background:#333;">
            <div class="inner">
              <h4><div  id="labelcounted" name="labelcounted" >0.0000000000</div></h4>

              <p>BITCOIN: <?Php echo " ".$arrayCVF; ?></p>
            </div>
            <div class="icon">
            <i><img src="images/b1.png" alt="" name="bitimg" width="39" height="38" id="bitimg"/></i>
            </div>
             <div align="center" class="small-box-footer">
             <form id="form5" name="form5" method="post" action="">
            <input type="submit" id="subMining1" name="subMining1" value="<?Php echo $Btmnl=$arraycount['btnml']; ?>" Style=" background-color: transparent; border-radius: 10px;"/>  <i class="fa fa-usd"></i>
             </form>
            </div>
         </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box" style="background:#333;">
            <div class="inner">
              <h4><div  id="labellite" name="labellite" >0.0000000000</div></h4>

              <p>LITECOIN: <?Php echo " ".$CashLiteF; ?></p>
            </div>
            <div class="icon">
              <i><img src="images/l1.png" alt="" name="ltcimg" width="39" height="38" id="ltcimg"/></i>
            </div>
             <div align="center" class="small-box-footer">
             <form id="frmMingLtc" name="frmMingLtc" method="post" action="">
            <input type="submit" id="subMining4" name="subMining4" value="<?Php echo $BtnLtc = $arraybutt['btnltc']; ?>" Style=" background-color: transparent; border-radius: 10px; "/>  <i class="fa fa-usd"></i>
             </form>
            </div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box" style="background:#333;">
            <div class="inner">
              <h4><div  id="labeldoge" name="dogecounted" >0.0000000000</div></h4>

              <p>DOGECOIN: <?Php echo " ".$CashDogeF; ?></p>
            </div>
            <div class="icon">
              <img src="images/d1.png" alt="" name="dogeimg" width="39" height="38" id="dogeimg"/>
            </div>
             <div align="center" class="small-box-footer">
             <form id="frmMingDoge" name="frmMingDoge" method="post" action="">
            <input type="submit" id="subMining3" name="subMining3" value="<?Php echo $BtnDoge = $arraybutt['btndoge']; ?>" Style=" background-color: transparent; border-radius: 10px; "/>  <i class="fa fa-usd"></i>
             </form>
            </div>
          </div>
        </div>
        <!-- ./col -->

      













      </div>
      
      <div id="tableOUR">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" Style="color: #00C0EF;">Hash-700mx <?Php echo " ".$DVST; ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Cryptocurrency</th>
                  <th>Per Day</th>
                  <th>Per Month</th>
                  <th>Per Year</th>
                  <th>Per Three Years</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Bitcoin</td>
                  <td><?Php echo number_format($daydvsbit,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($BITdvs,8,'.',''); ?></td>
                  <td><?Php echo number_format($yeardvsbit,'8','.',''); ?></td>
                  <td><?Php echo number_format($threedvsbit,'8','.',''); ?></td>
                </tr>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          </div>
          <!-- /.box -->
    <!-- /.content -->
  </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" Style="color: #605CA8;">Hash-300m <?Php echo " ".$CntMXC; ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Cryptocurrency</th>
                  <th>Per Day</th>
                  <th>Per Month</th>
                  <th>Per Year</th>
                  <th>Per Three Years</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Bitcoin</td>
                  <td><?Php echo number_format($daysmcbit,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($BITsmc,'8','.',''); ?></td>
                  <td><?Php echo number_format($yearsmcbit,'8','.',''); ?></td>
                  <td><?Php echo number_format($threesmcbit,'8','.',''); ?></td>
                </tr>
                </tbody>
                  <tbody>
                <tr>
                  <td>Litecoin</td>
                  <td><?Php echo number_format($LBDliteday,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($LBDLitNEWe,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDliteyear,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDlitethree,'8','.',''); ?></td>
                </tr>
                </tbody>
                   <tbody>
                <tr>
                  <td>Dogecoin</td>
                  <td><?Php echo number_format($LBDdogday,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($LBDDogNEWe,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDdogyear,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDdogthree,'8','.',''); ?></td>
                </tr>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          </div>
          <!-- /.box -->
    <!-- /.content -->
  </div>
   <!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" Style="color: #DD4B39;">Hash-500m <?Php echo " ".$DVSMini; ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Cryptocurrency</th>
                  <th>Per Day</th>
                  <th>Per Month</th>
                  <th>Per Year</th>
                  <th>Per Three Years</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Bitcoin</td>
                  <td><?Php echo number_format($dayminibit,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($BITmini,'8','.',''); ?></td>
                  <td><?Php echo number_format($yearminibit,'8','.',''); ?></td>
                  <td><?Php echo number_format($threeminibit,'8','.',''); ?></td>
                </tr>
                </tbody>
                  <tbody>
                <tr>
                  <td>Litecoin</td>
                  <td><?Php echo number_format($LBDlitefiday,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($LBDLiNEWte,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDlitefiyear,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDlitefithree,'8','.',''); ?></td>
                </tr>
                </tbody>
                   <tbody>
                <tr>
                  <td>Dogecoin</td>
                  <td><?Php echo number_format($LBDDogefiday,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($LBDDoNEWge,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDDogefiyear,'8','.',''); ?></td>
                  <td><?Php echo number_format($LBDDogefithree,'8','.',''); ?></td>
                </tr>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          </div>
          <!-- /.box -->
    <!-- /.content -->
  </div>
     <!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" Style="color: #83D3C9;">Hash-700mx + Hash-300m + Hash500m = <?Php echo " ".$CloudOurBit." "; ?>Your total power</h3>
            </div>
<?Php
$bitGen = ($daydvsbit + $daysmcbit + $dayminibit);
$bitGenm = ($BITdvs + $BITsmc + $BITmini);
$bitGeny = ($yeardvsbit + $yearsmcbit + $yearminibit);
$bitGent = ($threedvsbit + $threesmcbit + $threeminibit);
$LiteGen = ($LBDliteday + $LBDlitefiday);
$LiteGenm = ($LBDLitNEWe + $LBDLiNEWte);
$LiteGeny = ($LBDliteyear + $LBDlitefiyear);
$LiteGent = ($LBDlitethree + $LBDlitefithree);
$DogeGen = ($LBDdogday + $LBDDogefiday);
$DogeGenm = ($LBDDogNEWe + $LBDDoNEWge);
$DogeGeny = ($LBDdogyear + $LBDDogefiyear);
$DogeGent = ($LBDdogthree + $LBDDogefithree);
?>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Cryptocurrency</th>
                  <th>Per Day</th>
                  <th>Per Month</th>
                  <th>Per Year</th>
                  <th>Per Three Years</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Bitcoin</td>
                  <td><?Php echo number_format($bitGen,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($bitGenm,'8','.','');  ?></td>
                  <td><?Php echo number_format($bitGeny,'8','.',''); ?></td>
                  <td><?Php echo number_format($bitGent,'8','.',''); ?></td>
                </tr>
                </tbody>
                  <tbody>
                <tr>
                  <td>Litecoin</td>
                  <td><?Php echo number_format($LiteGen,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($LiteGenm,'8','.',''); ?></td>
                  <td><?Php echo number_format($LiteGeny,'8','.',''); ?></td>
                  <td><?Php echo number_format($LiteGent,'8','.',''); ?></td>
                </tr>
                </tbody>
                   <tbody>
                <tr>
                  <td>Dogecoin</td>
                  <td><?Php echo number_format($DogeGen,'8','.',''); ?>
                  </td>
                  <td><?Php echo number_format($DogeGenm,'8','.',''); ?></td>
                  <td><?Php echo number_format($DogeGeny,'8','.',''); ?></td>
                  <td><?Php echo number_format($DogeGent,'8','.',''); ?></td>
                </tr>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          </div>
          <!-- /.box -->
    <!-- /.content -->
  </div>
  </div>
  </section>
  </div>
  <footer class="main-footer" style="background: #333; color:white;">
    <strong>Copyright &copy; 2017 <a href="/">TCC</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-arrow-down"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">TCC</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="faq.html">
              <i class="menu-icon fa fa-mortar-board bg-red"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">FAQ</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="news.php">
              <i class="menu-icon fa fa-newspaper-o bg-yellow"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">NEWS</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="support.php">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">SUPPORT</h4>
              </div>
            </a>
          </li>
        </ul>
        </div>
        </div>
  </aside>
</div>
<?Php
if ($BtnDoge == "MINING") {
$x1 = "0";
}
else {
$x1 = "1";
}
if ($BtnDvs == "MINING") {
$y1 = "0";
}
else {
$y1 = "1";
}
if ($BtnLtc == "MINING") {
$z1 = "0";
}
else {
$z1 = "1";
}
if ($Btmnl == "MINING") {
$x2 = "0";
}
else {
$x2 = "1";
}
if ($BtmnDVS == "MINING") {
$y2 = "0";
}
else {
$y2 = "1";
}
if ($BtmnMXC == "MINING") {
$z2 = "0";
}
else {
$z2 = "1";
}
$xyzSUM = ($x1 + $y1 + $z1 + $x2 + $y2 + $z2);
if ($xyzSUM == "0") {
include("qur.php");
}
?>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
</body>
</html>
