<?php
include_once("bd.php");
if(empty($login) and empty($password)){
require("main.html");
}
include_once("incminingltcdog.php");
include_once("intmone.php");
include_once("initsmc.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Smc-hash</title>
  	<link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
      <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php
$DBCash = mysql_query("SELECT Cash FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$DBLtcDoge = mysql_query("SELECT Cashdoge, Cashlite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$array = mysql_fetch_array($DBCash);
$arrayCdoge = mysql_fetch_array($DBLtcDoge);
$arrayCF = $array['Cash'];
$CashDoge = $arrayCdoge['Cashdoge'];
$CashLite = $arrayCdoge['Cashlite'];
$arrayCVF = number_format($arrayCF, 8, '.', '');
$CashDogeF = number_format($CashDoge, 8, '.','');
$CashLiteF = number_format($CashLite, 8, '.','');
$currency = "USD";
$exchange_query_result = file_get_contents('https://blockchain.info/ru/ticker');
$exchange_data_obj = json_decode($exchange_query_result);
$KURS= "USD in BTC: ".$exchange_data_obj->$currency->last;
//-----------------------------------------------------------
$DBRATE = mysql_query("SELECT usdinbtc, dogeusd, ltcusd, dogebtc, ltcbtc FROM costsmc WHERE id='1' ");
$arrayRATE = mysql_fetch_array($DBRATE);
$usdinbtc = $arrayRATE['usdinbtc'];
$dogeusd = $arrayRATE['dogeusd'];
$ltcusd = $arrayRATE['ltcusd'];
$dogebtc = $arrayRATE['dogebtc'];
$ltcbtc = $arrayRATE['ltcbtc'];
?>
<?Php
$NOTDVS = "You have enough money";
$DBPack = mysql_query("SELECT InCash, InPack FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrayPack = mysql_fetch_array($DBPack);
$dincash = $arrayPack['InCash'];
$dinpack = $arrayPack['InPack'];
$DBDogePack = mysql_query("SELECT Cashdoge FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrayPackdoge = mysql_fetch_array($DBDogePack);
$CashPackDoge = $arrayPackdoge['Cashdoge'];
$CashPackDogeF = number_format($CashPackDoge, 8, '.','');
$CountDogep = number_format($_POST['txtPack'],8,'.','');
//--------------------------------------------------------------------
if ($CountDogep == "100000.00000000"){
$Packcnt = "1";
}
if ($CountDogep == "200000.00000000"){
$Packcnt = "2";
}
if ($CountDogep == "300000.00000000"){
$Packcnt = "3";
}
if ($CountDogep == "400000.00000000"){
$Packcnt = "4";
}
if ($CountDogep == "500000.00000000"){
$Packcnt = "5";
}
if ($CountDogep == "600000.00000000"){
$Packcnt = "6";
}
if ($CountDogep == "700000.00000000"){
$Packcnt = "7";
}
if ($CountDogep == "800000.00000000"){
$Packcnt = "8";
}
if ($CountDogep == "900000.00000000"){
$Packcnt = "9";
}
if ($CountDogep == "1000000.00000000"){
$Packcnt = "10";
}
//--------------------------------------------------------------------
if  (isset($_POST['btnInvest'])) {
$PackOurCash = $dincash + $CountDogep;
$PackOur=$dinpack+$Packcnt;
$SumPackour=$CashPackDogeF-$CountDogep;
if ($CashPackDogeF < $CountDogep ) {
echo "Not enough money!";
echo "<script>alert(\"Not enough money! ".$NOTDVS."\");</script>";
 header('Refresh: 1; URL=invest.php');
exit;
}
else{
mysql_query("UPDATE ltcdoge SET InCash = '$PackOurCash' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1'");
mysql_query("UPDATE ltcdoge SET InPack = '$PackOur' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1'");
mysql_query("UPDATE ltcdoge SET Cashdoge = '$SumPackour' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1'");
echo "<script>alert(\"You bought ".$Packcnt." Package"."\");</script>";
  header('Refresh: 2; URL=/');
  exit;
}
}
?>
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>Smc-hash</b>mining</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Smc-hash</b> mining</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-paper-plane-o"></i>
              <span class="label label-success">$</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Actual Exchange Rates</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                   <li>
                      <h4>
                       <?Php echo " USD in BTC: ".$usdinbtc ; ?>
                        <small><i class="fa fa-spinner"></i></small>
                      </h4>
                  </li>
                  <li>
                      <h4>
                       <?Php echo " USD in LTC: ".$ltcusd; ?>
                        <small><i class="fa fa-spinner"></i></small>
                      </h4>
                  </li>
                  <li>
                      <h4>
                        <?Php echo " USD in DOGE: ".$dogeusd; ?>
                        <small><i class="fa fa-spinner"></i></small>
                      </h4>
                  </li>
                  <li>
                      <h4>
                        <?Php echo " BTC in DOGE: ".$dogebtc; ?>
                        <small><i class="fa fa-spinner"></i></small>
                      </h4>
                  </li>
                  <li>
                      <h4>
                        <?Php echo " BTC in LTC: ".$ltcbtc; ?>
                        <small><i class="fa fa-spinner"></i></small>
                      </h4>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
             <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i>PACKAGE</i>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Your investment</li> <br>
              <p>Start 10.03.2017</p>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                <h4>
                  <li>
                      <i> <?Php echo "Package: ".$dinpack; ?></i>
                  </li>
                  <li>
                     <i> <?Php echo "Investments: ".$dincash; ?></i>
                  </li>
                  <li>
                      <i> <?Php echo "Counted: "."0.00000000"; ?></i>
                  </li>
                  </h4>
                </ul>
              </li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-usd"></i>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Cash</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                <h4>
                  <li>
                      <i><img src="images/lb1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$arrayCVF; ?></i> BTC
                  </li>
                  <li>
                     <i><img src="images/ll1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashLiteF; ?></i> LTC
                  </li>
                  <li>
                      <i><img src="images/ld1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashDogeF; ?></i> DOGE
                  </li>
                  </h4>
                </ul>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">

              <span class="hidden-xs"><?Php echo $login; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="profile.php" class="btn btn-default btn-flat">Account</a>
                </div>
                <div class="pull-right">
                  <a href="exit.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-windows"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <li class="treeview">
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="buycloud.php">
            <i class="fa fa-cloud"></i>
            <span>Clouds</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="buycloud.php#h500"><i class="fa fa-circle-o text-red"></i> <span>HASH-500m</span></a></li>
            <li><a href="buycloud.php#h300"><i class="fa fa-circle-o text-purple"></i> <span>HASH-300m</span></a></li>
            <li><a href="buycloud.php#h700"><i class="fa fa-circle-o text-aqua"></i> <span>HASH-700mx</span></a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-plus"></i>
            <span>Deposit</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="deposit.php#hdbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="deposit.php#hdlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="deposit.php#hddoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-minus"></i> <span>Withdraw</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
             <li><a href="withdraw.php#hbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="withdraw.php#hlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="withdraw.php#hdoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
            <li class="active treeview">
          <a href="invest.php">
            <i class="fa fa-usd"></i> <span Style="color:#F07800;">Investments in DogeCoin</span>
          </a>
        </li>
         <li>
          <a href="profile.php">
            <i class="fa fa-user"></i> <span>Account</span>
          </a>
        </li>
           <li>
          <a href="history.php">
            <i class="fa fa-book"></i> <span>History</span>
          </a>
        </li>
        <li class="treeview">
          <a href="exit.php">
            <i class="fa fa-power-off"></i> <span>Signout</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Investments
        <small><?Php echo $login; ?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-cloud"></i> Home</a></li>
        <li class="active">Investments</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     <div class="col-lg-4 goright">
				<p><a href="news.php#pack"><i class="fa fa-share"></i> Learn more about this... </a></p>
			</div>
    <h1>March 10, we are launching a new mining Dogecoin farm.</h1> <br>
    <h3>We suggest you to invest in equipment for mining Dogecoin.</h3>
    <h3>Attachments will be accepted until 01.03.2017. </h3>
    <h3>The number of packages is limited to 1000. Minimum purchase 1 pack. Starting a new farm 10/03/2017</h3>
    <h3>Investors allocated 1,000 packages. </h3>
    <h3>After running the farm 10.03.2017 you will receive 50% of mining on the new equipment according to the number of packages purchased. </h3>
    <h3>50% of each package gets company Smc-hash.</h3>
        <div class="row">
	        <p>
    <p><a name="h500"></a></p>
          <div class="small-box bg-yellow">
            <div class="inner">
            <h4><span>Dogecoin: </span><div id="txtDVSmp">100000.00000000</div></h4>
              <p>The cost of the package: 1 package = 100000.00000000 Dogecoin</p>
            </div>
            <div>
<form class="frmInvest" name="frmInvest" id= "frmInvest" method="post" action="">
 <label>
      <input name="txtIddogep" type="text" id="txtIddogep" value="<?Php echo $CashDogeF; ?>" hidden="hidden" >
      </label>
    </h2>
          <input name="txtlabelvP" type="text" id="txtlabelvP" value="000000" hidden="hidden" >
              <label>
        <input name="txtPrdp" type="text" id="txtPrdp" value="100000.00000000" hidden="hidden"  >
        </label>
        <input type="text" name="txtPack" id="txtPack" value="100000.00000000" hidden="hidden" />
      <p align="center"><strong><span>Package</span>
        <select name="slctPackage" id="slctPackage" style="background-color:transparent; border-radius: 7px; border-color:#A185AD;" onChange="GetDataPackage(); fn();"> </strong>
		  <option value="nOne" style="color:#000000;">1</option>
          <option value="nTwo" style="color:#000000;">2</option>
          <option value="nThree" style="color:#000000;">3</option>
          <option value="nFore" style="color:#000000;">4</option>
          <option value="nFive" style="color:#000000;">5</option>
          <option value="nSix" style="color:#000000;">6</option>
          <option value="nSeven" style="color:#000000;">7</option>
          <option value="nEight" style="color:#000000;">8</option>
          <option value="nNine" style="color:#000000;">9</option>
          <option value="nTen" style="color:#000000;">10</option>
          </select></p>

  </div>
            <br>
            <div class="icon">
              <img src="images/pammportfel.png" alt="" />
            </div>
            <div align="center" class="small-box-footer">
            <input type="submit" id="btnInvest" name="btnInvest" value="Buy" Style="border-radius: 10px;"/>  <i class="fa fa-usd"></i>
            </form>
            </div>
          </div>
				  </p>
    </div>
  </div>
  </section>
  <footer class="main-footer">
    <strong>Copyright &copy; 2016 <a href="/">Smc-hash</a>.</strong> All rights
    reserved. <li> <a href="ppolicy.php">Privacy Policy</a></li>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-arrow-down"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Smc-hash</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="faq.html">
              <i class="menu-icon fa fa-mortar-board bg-red"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">FAQ</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="news.php">
              <i class="menu-icon fa fa-newspaper-o bg-yellow"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">NEWS</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="support.php">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">SUPPORT</h4>
              </div>
            </a>
          </li>
        </ul>
        </div>
        </div>
  </aside>
</div>
 <script type="text/javascript">
  function GetDataPackage()
  {
  var sum_dogep = document.frmInvest.txtIddogep.value;
  var pr_dogep = document.frmInvest.txtPrdp.value;
  	 var selind = document.getElementById("slctPackage").options.selectedIndex;
	  var txt= document.getElementById("slctPackage").options[selind].text;
   var val= document.getElementById("slctPackage").options[selind].value;
     var znakP= document.getElementById("txtlabelvP").value = val;
     if (znakP == "nOne") {
	  document.getElementById("txtDVSmp").innerHTML = pr_dogep;
      document.frmInvest.txtPack.value = pr_dogep;
	 }
	  if (znakP == "nTwo") {
	 var cur_bitp = (+pr_dogep + +100000).toFixed(8);
	 document.getElementById("txtDVSmp").innerHTML = cur_bitp;
     document.frmInvest.txtPack.value = cur_bitp;
	 }
	  if (znakP == "nThree") {
     var cur_bitp1 = (+pr_dogep + +200000).toFixed(8);
	 document.getElementById("txtDVSmp").innerHTML = cur_bitp1;
     document.frmInvest.txtPack.value = cur_bitp1;
	 }
     if (znakP == "nFore") {
      var cur_bitp2 = (+pr_dogep + +300000).toFixed(8);
	  document.getElementById("txtDVSmp").innerHTML = cur_bitp2;
      document.frmInvest.txtPack.value = cur_bitp2;
	 }
	  if (znakP == "nFive") {
	 var cur_bitp3 = (+pr_dogep + +400000).toFixed(8);
	 document.getElementById("txtDVSmp").innerHTML = cur_bitp3;
     document.frmInvest.txtPack.value = cur_bitp3;
	 }
	  if (znakP == "nSix") {
     var cur_bitp4 = (+pr_dogep + +500000).toFixed(8);
	 document.getElementById("txtDVSmp").innerHTML = cur_bitp4;
     document.frmInvest.txtPack.value = cur_bitp4;
	 }
     if (znakP == "nSeven") {
      var cur_bitp5 = (+pr_dogep + +600000).toFixed(8);
	  document.getElementById("txtDVSmp").innerHTML = cur_bitp5;
      document.frmInvest.txtPack.value = cur_bitp5;
	 }
	  if (znakP == "nEight") {
	 var cur_bitp6 = (+pr_dogep + +700000).toFixed(8);
	 document.getElementById("txtDVSmp").innerHTML = cur_bitp6;
     document.frmInvest.txtPack.value = cur_bitp6;
	 }
	  if (znakP == "nNine") {
     var cur_bitp7 = (+pr_dogep + +800000).toFixed(8);
	 document.getElementById("txtDVSmp").innerHTML = cur_bitp7;
     document.frmInvest.txtPack.value = cur_bitp7;
	 }
     if (znakP == "nTen") {
     var cur_bitp8 = (+pr_dogep + +900000).toFixed(8);
	 document.getElementById("txtDVSmp").innerHTML = cur_bitp8;
     document.frmInvest.txtPack.value = cur_bitp8;
	 }
  }
        </script>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
</body>
</html>