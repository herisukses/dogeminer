<?Php
                    $email = "emilhasanov98@gmail.com";
                    $from = 'smc@smc-hash.com';
                     $headerd = "From: \"Admin\" <smc@smc-hash.com>\n";
                    $headerd .= "Content-type: text/plain; charset=\"utf-8\"";
					$subject = "Receive 0.00200000 Btc";
					$message = "Hello! 0.002 BTC Received in your account. Sincerely SMC-hash team";
					mail($email, $subject, $message, $headerd);
        $connect = fsockopen ('127.0.0.1', 25, $errno, $errstr, 30);
        if(!$connect){
            echo json_encode($errno);
        } else {
            fputs($connect, "HELO localhost\r\n");
            fputs($connect, "MAIL FROM: $from\n");
            fputs($connect, "RCPT TO: $email\n");
            fputs($connect, "DATA\r\n");
            fputs($connect, "Content-Type: text/plain; charset=UTF-8");
            fputs($connect, "MIME-Version: 1.0\nContent-Transfer-Encoding: 7bit\n");
            fputs($connect, "To: $email\r\n");
            fputs($connect, "Subject: =?utf-8?b?".base64_encode($subject)."?=\r\n");
            fputs($connect, $message." \r\n");
            fputs($connect, ".\r\n");
            fputs($connect, "RSET\r\n");
        }
        fclose($connect);
				}
?>