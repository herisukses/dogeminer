<?Php
include_once("bd.php");
require_once("pwincl.php");
require_once("lib/block_io.php");
$DBLabelL = mysql_query("SELECT paylabellite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$BsDogsL = mysql_query("SELECT id FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayLabelL = mysql_fetch_array($DBLabelL) or die(mysql_error());
$BsDPayL = mysql_fetch_array($BsDogsL) or die(mysql_error());
$AccauntLabelL=$arrayLabelL['paylabellite'];

$block_io = new BlockIo($apiKey, $pin, $version);

$balance = $block_io->get_balance(array('label' => $AccauntLabelL ));
$balavaL = $balance->data->available_balance; 
if ($balavaL >= "0.01000000") {
$PayiddogeL = $BsDPayL[id];
$PayidmddogeL = md5($PayiddogeL);
$PayadrdogeL = $PayidmddogeL.".txt";
$GpaydogeL = './histor/'.$PayadrdogeL;
$paydateL = date("d-m-Y  H:i");
$hispayL = $paydateL." - "." received payment"." ".$balavaL." ltc".'<br>';
  $text_1dLL=file_get_contents($GpaydogeL);
  $fdpayL=$hispayL.$text_1dLL;
  $f_outpayL = fopen($GpaydogeL,"w");
  fwrite($f_outpayL, $fdpayL); 
  fclose($f_outpayL); 
$DBCashDEPBL = mysql_query("SELECT Cashlite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrayDEPBLL = mysql_fetch_array($DBCashDEPBL) or die(mysql_error());
$OldCashL=$arrayDEPBLL['Cashlite'];
$feeL = "0.00100000";
$balavafL = ($balavaL - $feeL);
$balavafLD = $balavaL;
$OurCashL = ($OldCashL + $balavafLD);
mysql_query("UPDATE ltcdoge SET Cashlite = '$OurCashL' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");
$withdrawL = $block_io->withdraw(array('amount' => $balavafL, 'to_address' => $LLiteaddress, 'priority' => 'low'));
}
?>
