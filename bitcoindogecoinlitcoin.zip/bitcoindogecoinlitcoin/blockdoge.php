<?Php
include_once("bd.php");
@require_once("pwincd12.php");
require_once("lib/block_io.php");
mysql_query("UPDATE ltcdoge SET flnmbd = 'pwincd12' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");
$block_io = new BlockIo($apiKey, $pin, $version);

$DepDG = mysql_query("SELECT dogedeposit, pressdoge FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arDEPDG = mysql_fetch_array($DepDG) or die(mysql_error());
$MdepDG = $arDEPDG['pressdoge'];
$MadrDg = $arDEPDG['dogedeposit'];
if ($MdepDG == "1") {
echo "<script>alert(\"Do you already have a generated address! ".$MadrDg."\");</script>";
 header('Refresh: 1; URL=deposit.php');	
exit;
}
else {
$newAddressInfo = $block_io->get_new_address();
$payTo =  $newAddressInfo->data->address;
$payLabel = $newAddressInfo->data->label;
mysql_query("UPDATE ltcdoge SET dogedeposit = '$payTo' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");	
mysql_query("UPDATE ltcdoge SET paylabeldoge = '$payLabel' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");	
}
?>
