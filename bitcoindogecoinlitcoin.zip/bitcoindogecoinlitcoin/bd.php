<?php
session_start();

mysql_connect ("localhost","DATABAS USER","DATABASE PASS");
mysql_select_db ("DATABASE NAME");
$login = $_SESSION['login'];
$password = $_SESSION['password'];
$id_user = $_SESSION['id'];
$ip = $_SERVER['REMOTE_ADDR'];
?>
 
