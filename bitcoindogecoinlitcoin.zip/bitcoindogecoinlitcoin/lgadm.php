<?php
include_once("asdm.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>TCC ADMIN_PANEL</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>

  <body>

<?php
if (isset($_POST['login'])) {
	$alogina = $_POST['login'];
	if ($alogina == '') {
		unset($alogina);
		exit ("Enter you login!");
	}
}
if (isset($_POST['password'])) {
	$apassworda=$_POST['password'];
	if ($apassworda =='') {
		unset($apassworda);
		exit ("enter password");
	}
}

$alogina = stripslashes($alogina);
$alogina = htmlspecialchars($alogina);

$apassworda = stripslashes($apassworda);
$apassworda = htmlspecialchars($apassworda);


$alogina = trim($alogina);
$apassworda = trim($apassworda);

$apassworda = md5($apassworda);

$ausera = mysql_query("SELECT id FROM gusers WHERE glogin='$alogina' AND gpassword='$apassworda' AND activation='2'");
$aid_usera = mysql_fetch_array($ausera);
if (empty($aid_usera['id'])){
    include_once("mainentr.php");
    echo "<script>alert(\"login or password are incorrect."."\");</script>";
	exit;
}
else {


    $_SESSION['password']=$apassworda;
	$_SESSION['login']=$alogina;
    $_SESSION['id']=$aid_usera['id'];

}
echo "<meta http-equiv='Refresh' content='0; URL=mainadm.php'>";
?>
</body>
</html>