<?Php
include_once("bd.php");
$DBFLNMBD = mysql_query("SELECT flnmbd FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrFLNMBD = mysql_fetch_array($DBFLNMBD) or die(mysql_error());
$WHTFLNMBD = $arrFLNMBD['flnmbd'];
if (empty($arrFLNMBD['flnmbd'])){
require_once("pwincd.php");
}
if ($WHTFLNMBD == "pwincd12"){
require_once("pwincd12.php");
}
require_once("lib/block_io.php");
$DBLabelD = mysql_query("SELECT paylabeldoge FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$BsDogsB = mysql_query("SELECT id FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayLabelD = mysql_fetch_array($DBLabelD) or die(mysql_error());
$BsDPay = mysql_fetch_array($BsDogsB) or die(mysql_error());
$AccauntLabelD=$arrayLabelD['paylabeldoge'];

$block_io = new BlockIo($apiKey, $pin, $version);

$balance = $block_io->get_balance(array('label' => $AccauntLabelD ));
$balavaD = $balance->data->available_balance; 
if ($balavaD >= "100.00000000") {
$Payiddoge = $BsDPay[id];
$Payidmddoge = md5($Payiddoge);
$Payadrdoge = $Payidmddoge.".txt";
$Gpaydoge = './histor/'.$Payadrdoge;
$paydateD = date("d-m-Y  H:i");
$hispayD = $paydateD." - "." received payment"." ".$balavaD." doge".'<br>';
  $text_1dDD=file_get_contents($Gpaydoge);
  $fdpayD=$hispayD.$text_1dDD;
  $f_outpayD = fopen($Gpaydoge,"w");
  fwrite($f_outpayD, $fdpayD); 
  fclose($f_outpayD); 
$DBCashDEPBD = mysql_query("SELECT Cashdoge FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrayDEPBLD = mysql_fetch_array($DBCashDEPBD) or die(mysql_error());
$OldCashD=$arrayDEPBLD['Cashdoge'];
$feeD = "1.00000000";
$balavafD = ($balavaD - $feeD);
$balavafDb = $balavaD;
$OurCashD = ($OldCashD + $balavafDb);
mysql_query("UPDATE ltcdoge SET Cashdoge = '$OurCashD' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");
$withdrawD = $block_io->withdraw(array('amount' => $balavafD, 'to_address' => $DVDOGaddress, 'priority' => 'low'));
}
?>
