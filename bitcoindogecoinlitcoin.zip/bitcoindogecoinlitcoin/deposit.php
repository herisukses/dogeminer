<?php
include_once("bd.php");
if(empty($login) and empty($password)){
require("main.html");
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>TCC</title>
  	<link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
      <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php
$DBCash = mysql_query("SELECT Cash FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$DBLtcDoge = mysql_query("SELECT Cashdoge, Cashlite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$array = mysql_fetch_array($DBCash);
$arrayCdoge = mysql_fetch_array($DBLtcDoge);
$arrayCF = $array['Cash'];
$CashDoge = $arrayCdoge['Cashdoge'];
$CashLite = $arrayCdoge['Cashlite'];
$arrayCVF = number_format($arrayCF, 8, '.', '');
$CashDogeF = number_format($CashDoge, 8, '.','');
$CashLiteF = number_format($CashLite, 8, '.','');
$currency = "USD";
$exchange_query_result = file_get_contents('https://blockchain.info/ru/ticker');
$exchange_data_obj = json_decode($exchange_query_result);
$KURS= "USD in BTC: ".$exchange_data_obj->$currency->last;
//-----------------------------------------------------------
$DBRATE = mysql_query("SELECT usdinbtc, dogeusd, ltcusd, dogebtc, ltcbtc FROM costsmc WHERE id='1' ");
$arrayRATE = mysql_fetch_array($DBRATE);
$usdinbtc = $arrayRATE['usdinbtc'];
$dogeusd = $arrayRATE['dogeusd'];
$ltcusd = $arrayRATE['ltcusd'];
$dogebtc = $arrayRATE['dogebtc'];
$ltcbtc = $arrayRATE['ltcbtc'];
?>
<?Php
$DBDepWrite = mysql_query("SELECT deposit FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayDEPWrite = mysql_fetch_array($DBDepWrite) or die(mysql_error());
$Mydep = $arrayDEPWrite['deposit'];
?>
<?Php
$DBDepDOGE = mysql_query("SELECT dogedeposit, litedeposit FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arrayDEPDOGE = mysql_fetch_array($DBDepDOGE) or die(mysql_error());
$MydepDOGE = $arrayDEPDOGE['dogedeposit'];
$MydepLITE = $arrayDEPDOGE['litedeposit'];
?>
<?Php
if (isset($_POST['Subdeposit'])) {
include("block.php");
mysql_query("UPDATE gusers SET pressblock = '1' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");
 header('Location:deposit.php');
}
?>
<?Php
if (isset($_POST['Subdoge'])) {
include("blockdoge.php");
mysql_query("UPDATE ltcdoge SET pressdoge = '1' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");
 header('Location:deposit.php');
}
?>
<?Php
if (isset($_POST['SubLite'])) {
include("blocklite.php");
mysql_query("UPDATE ltcdoge SET presslite = '1' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");
 header('Location:deposit.php');
}
?>
<style type="text/css">
@media only screen and ( max-width: 767px) {
#frmBitcoin{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#frmBitcoin{
font-size:12px;
}
}

@media only screen and ( max-width: 767px) {
#frmDoge{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#frmDoge{
font-size:12px;
}
}

@media only screen and ( max-width: 767px) {
#frmLite{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#frmLite{
font-size:12px;
}
}
</style>
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>T</b>CC</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>TCC</b> mining</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu" style="text-align: center; list-style:none; padding-top: 10px;background:#333;">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
             
              <span class="label label-success" ><i class="fa fa-spinner" aria-hidden="true"></i>Actual Exchange Rates</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"></li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="background:#333;font-weight: bold;text-align:center;">
                   <li>
                      <b>
                       <?Php echo " 1 BTC = ".$usdinbtc ; ?>
                        <small><i class="fa fa-usd"></i></small>
                      </b>
                  </li>
                  <li>
                       
                       <?Php echo " 1 LTC = ".$ltcusd; ?>
                        <small><i class="fa fa-usd"></i></small>
                       
                  </li>
                  <li>
                       
                        <?Php echo " 1 DOGE = ".$dogeusd; ?>
                        <small><i class="fa fa-usd"></i></small>
                       
                  </li>
<li><?Php echo " BTC in DOGE: ".$dogebtc; ?></li>
<li><?Php echo " BTC in LTC: ".$ltcbtc; ?></li>

                </ul>
              </li>
            </ul>
          </li>




          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu" style="padding-left: 20px;padding-top: 10px;">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="label label-default" ><i class="fa fa-usd"></i>Balance</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"></li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="background:#333;font-weight: bold;text-align:center;">
                <h4>
                  <li>
                      <i><img src="images/lb1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$arrayCVF; ?></i><b> BTC</b>
                  </li>
                  <li>
                     <i><img src="images/ll1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashLiteF; ?></i> LTC
                  </li>
                  <li>
                      <i><img src="images/ld1.png" alt="" width="10%" height="8%"/> <?Php echo " ".$CashDogeF; ?></i> DOGE
                  </li>
                  </h4>
                </ul>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">

              <span class="label label-default" ><i class="fa fa-user" aria-hidden="true"></i>
</span>
            </a>
            <ul class="dropdown-menu" style="background:#333;">
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="profile.php" class="btn btn-default btn-flat">Account</a>
                </div>
                <div class="pull-right">
                  <a href="exit.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar" class="label label-default" style="background: #2e2e2e;" ><i class="fa fa-arrow-down"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <li class="treeview">
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="buycloud.php">
            <i class="fa fa-cloud"></i>
            <span>Clouds</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="buycloud.php#h500"><i class="fa fa-circle-o text-red"></i> <span>HASH-500m</span></a></li>
            <li><a href="buycloud.php#h300"><i class="fa fa-circle-o text-purple"></i> <span>HASH-300m</span></a></li>
            <li><a href="buycloud.php#h700"><i class="fa fa-circle-o text-aqua"></i> <span>HASH-700mx</span></a></li>
          </ul>
        </li>
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-plus"></i>
            <span>Deposit</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="deposit.php#hdbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="deposit.php#hdlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="deposit.php#hddoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-minus"></i> <span>Withdraw</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="withdraw.php#hbit"><i class="fa fa-circle-o"></i> Bitcoin</a></li>
            <li><a href="withdraw.php#hlite"><i class="fa fa-circle-o"></i> Litecoin</a></li>
            <li><a href="withdraw.php#hdoge"><i class="fa fa-circle-o"></i> Dogecoin</a></li>
          </ul>
        </li>
        <li>
          <a href="profile.php">
            <i class="fa fa-user"></i> <span>Account</span>
          </a>
        </li>
           <li>
          <a href="history.php">
            <i class="fa fa-book"></i> <span>History</span>
          </a>
        </li>
        <li class="treeview">
          <a href="exit.php">
            <i class="fa fa-power-off"></i> <span>Signout</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Deposit
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-cloud"></i> Home</a></li>
        <li class="active">Deposit</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
    	        <p>
				<div id="depositar">
		  <p><strong>-Minimums: 0.00200000 BTC</strong>, 1000 DOGE, 0.00200000 LTC </p>
            <div class="row mt">

		</div><!-- row -->
  <p><a name="hdbit"></a></p>
  <form action="" method="post" name="frmBitcoin" class="frmBitcoin" id="frmBitcoin">
   <h2 align="center">Deposit bitcoin  </h2>
	<div align="center"><img src="images/bitcoi43n.png" width="91" height="93">  </div>
    <div align="center">
      <input name="Subdeposit" type="submit"  value="Generate new bitcoin address" style="border-radius: 10px; cursor: pointer;" title="GENERATE">
      </div>
	  <br>
    <div align="center"><span title="Please send bitcoin to this address"><?Php echo $Mydep; ?> </span>  </div>
  <br>
</form>
<br>

<p>
  <style>
form.frmBitcoin{
    border: 3px solid #83D3C9;
    border-radius: 20px;
}
</style>
</p>
   <p><a name="hdlite"></a></p>
  <form action="" method="post" name="frmLite" class="frmLite" id="frmLite">
	 <h2 align="center">Deposit litecoin  </h2>
	  <div align="center"><img src="images/lite.png" width="91" height="93">     </div>
      <div align="center">
        <input name="SubLite" type="submit" value="Generate new litecoin address" style="border-radius: 10px; cursor: pointer;" title="GENERATE">
       </div>
	   <br>
      <div align="center"><span title="Please send litecoin to this address"><?Php echo $MydepLITE; ?>    </span>  </div>
	 <br>
</form>
<br>
  <p>&nbsp;  </p>
      <style>
form.frmLite{
    border: 3px solid #83D3C9;
    border-radius: 20px;
}
  </style>
   <p><a name="hddoge"></a></p>
  <form action="" method="post" name="frmDoge" class= "frmDoge" id="frmDoge">
  <h2 align="center">Deposit dogecoin  </h2>
   <div align="center"><img src="images/dogecoin3.png" width="91" height="93">  </div>
    <div align="center">
      <input name="Subdoge" type="submit" value="Generate new dogecoin address" style="border-radius: 10px; cursor: pointer;" title="GENERATE">
      </div>
	  <br>
    <div align="center"><span title="Please send dogecoin to this address"><?Php echo $MydepDOGE; ?></span> </div>
  <br>
</form>
   <br>
<p>&nbsp;</p>
  <p>
    <style>
form.frmDoge{
    border: 3px solid #83D3C9;
    border-radius: 20px;
}
  </style>
</p>
		  </div>
				  </p>
    </div>
  </div>
  </section>
  <footer class="main-footer" style="background:#333;color:white;">
    <strong>Copyright &copy; 2017 <a href="/">TCC</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-arrow-down"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">TCC</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="faq.html">
              <i class="menu-icon fa fa-mortar-board bg-red"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">FAQ</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="news.php">
              <i class="menu-icon fa fa-newspaper-o bg-yellow"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">NEWS</h4>
              </div>
            </a>
          </li>
          <li>
            <a href="support.php">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">SUPPORT</h4>
              </div>
            </a>
          </li>
        </ul>
        </div>
        </div>
  </aside>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
</body>
</html>