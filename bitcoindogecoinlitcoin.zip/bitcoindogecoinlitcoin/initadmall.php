<?Php include_once("asdm.php");?>
<?Php
$BONUSB = $_POST['txtBONb'];
$BONUSL = $_POST['txtBONl'];
$BONUSD = $_POST['txtBONd'];
if  (isset($_POST['btnBONb'])) {
mysql_query("UPDATE costsmc SET bnsB = '$BONUSB' WHERE id='1' ");
echo "<script>alert(\"OK"."\");</script>";
  header('Refresh: 2; URL=mainadm.php');
  exit;
}
if  (isset($_POST['btnBONl'])) {
mysql_query("UPDATE costsmc SET bnsL = '$BONUSL' WHERE id='1' ");
echo "<script>alert(\"OK"."\");</script>";
  header('Refresh: 2; URL=mainadm.php');
  exit;
}
if  (isset($_POST['btnBONd'])) {
mysql_query("UPDATE costsmc SET bnsD = '$BONUSD' WHERE id='1' ");
echo "<script>alert(\"OK"."\");</script>";
  header('Refresh: 2; URL=mainadm.php');
  exit;
}
?>