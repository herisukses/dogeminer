<?php include_once("bd.php"); ?>
<style type="text/css">
<!--
body {
	background-color: transparent;
	border-color:#83D3C9;
	border-bottom-style: double;
    border-radius: 20px;
	border-style: double;
	line-height:normal;
}
.стиль1 {
	font-size: 24px;
	font-weight: bold;
}
.стиль2 {
	color:#83D3C9;
	font-size: 18px;
}
-->
</style>
<?Php 
$DBRefframe = mysql_query("SELECT reffer_id, my_refflink FROM greffer WHERE rlogin='$login'AND rrpassword='$password' AND activation='1' ");
$Refmain = mysql_fetch_array($DBRefframe) or die(mysql_error());
$Refidframe = $Refmain['reffer_id'];
$Myrefframe = $Refmain['my_refflink'];
?>
<div align="center" class="стиль1">
  <p> </p>
  <form name="frmarrayref" method="post" action="">
  <br>
 <label></label>
  <h2 align="center" class="стиль1">Your refferals: </h2>
    <div align="left" class="стиль2"><?Php $DBvabref = mysql_query("SELECT * FROM greffer WHERE reffer_id='$Myrefframe'");
while ($Refvar = mysql_fetch_array($DBvabref))
{
$refherid = $Refvar['id'];
$refherlink = $Refvar['my_refflink'];
$refhername = $Refvar['name'];
if (empty($refhername)) {
$refhernamer = "NoName";
}
else {
$refhernamer = $Refvar['name'];
}
//------------------------------------

//------------------------------------
echo " ID " .$refherid." | ".$refherlink. " | ".$refhernamer." | "."<br />\n";
}  ?><br></div>
  </form>
  
  <p align="left">&nbsp;</p>
</div>
