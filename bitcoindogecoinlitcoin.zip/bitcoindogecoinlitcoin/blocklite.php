<?Php
include_once("bd.php");
require_once("pwincl.php");
require_once("lib/block_io.php");
$block_io = new BlockIo($apiKey, $pin, $version);
$DepLTC = mysql_query("SELECT litedeposit, presslite FROM ltcdoge WHERE flogin='$login'AND fpassword='$password' AND activation='1' ");
$arDEPLTC = mysql_fetch_array($DepLTC) or die(mysql_error());
$MdepLTC = $arDEPLTC['presslite'];
$MadrLtc = $arDEPLTC['litedeposit'];
if ($MdepLTC == "1") {
echo "<script>alert(\"Do you already have a generated address! ".$MadrLtc."\");</script>";
 header('Refresh: 1; URL=deposit.php');	
exit;
}
else {
$newAddressInfo = $block_io->get_new_address();
$payTo =  $newAddressInfo->data->address;
$payLabel = $newAddressInfo->data->label;
mysql_query("UPDATE ltcdoge SET litedeposit = '$payTo' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");	
mysql_query("UPDATE ltcdoge SET paylabellite = '$payLabel' WHERE flogin = '$login'  AND fpassword = '$password' AND activation='1' ");	
}
?>
