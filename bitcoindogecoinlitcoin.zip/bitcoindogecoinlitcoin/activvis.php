<!DOCTYPE HTML>
<html>
	<head>
		<title>SMC-hash</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body class="index">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1 id="logo"><a href="/">SMC-hash<span> Cloud mining cryptocurrency</span></a></h1>
					<nav id="nav">
						<ul>
							<li class="submenu">
								<a href="#">Menu</a>
								<ul>
                                    <li><a href="/">Main</a></li>
									<li><a href="main.html#calcd">Calculate</a></li>
									<li><a href="faq.html">Faq</a></li>
									<li><a href="news.php">News</a></li>
									<li><a href="support.php">Support</a></li>
                                    <li><a href="forgot.php">Forgot?</a></li>
								</ul>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">

					<!--
						".inner" is set up as an inline-block so it automatically expands
						in both directions to fit whatever's inside it. This means it won't
						automatically wrap lines, so be sure to use line breaks where
						appropriate (<br />).
					-->
					<div class="inner">

						<header>
							<h2>SMC-hash mining</h2>
						</header>
                          <h1>OK NOW LOGIN</h1>
						<footer>
                           <ul class="buttons vertical">
								<li><a href="javascript:look('divone');" class="button fit scrolly">Sign In</a></li>
							</ul>
                            <div id="divone" style="display:none">
	                        <form action="loginav.php" name="frmLogin" method="post">
	                        <input name="login" type="text" id="login" placeholder = "login" required><br>
	                        <input name="password" type="password" id="password" placeholder = "password" required><br>
	                        <input type="submit" value="GO" name="submit"  title="SIGN IN"><br>
                            </form>
                            </div>
						</footer>
					</div>

				</section>

			<!-- Footer -->
				<footer id="footer">

					<ul class="copyright">
						<li>&copy; SMC-hash cloud mining</li><li> <a href="/">Main</a></li><li> <a href="ppolicy.php">Privacy Policy</a></li>
					</ul>

				</footer>

		</div>

		<!-- Scripts -->
             <script>
               function look(type){
                param=document.getElementById(type);
                if(param.style.display == "none") param.style.display = "block";
                else param.style.display = "none"
             }
            </script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
			<script id="cid0020000142021425932" data-cfasync="false" async src="//st.chatango.com/js/gz/emb.js" style="width: 200px;height: 300px;">{"handle":"smc-hashmining","arch":"js","styles":{"a":"83D3C9","b":100,"c":"000000","d":"000000","k":"83D3C9","l":"83D3C9","m":"83D3C9","p":"10","q":"83D3C9","r":100,"pos":"br","cv":1,"cvbg":"83D3C9","cvfg":"000000","cvw":200,"cvh":30,"ticker":1,"fwtickm":1}}</script>

	</body>
</html>