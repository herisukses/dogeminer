<?Php include_once("bdl.php"); ?>
<?Php
$DBRATE = mysql_query("SELECT usdinbtc, dogeusd, ltcusd, ltcbtc FROM costsmc WHERE id='1' ");
$DBCOST = mysql_query("SELECT cost1, cost2, cost3, dogebtc FROM costsmc WHERE id='1' ");
$arrayRATE = mysql_fetch_array($DBRATE);
$arrayCOST = mysql_fetch_array($DBCOST);
$usdinbtc = $arrayRATE['usdinbtc'];
$dogeusd = $arrayRATE['dogeusd'];
$ltcusd = $arrayRATE['ltcusd'];
$dogebtc = $arrayCOST['dogebtc'];
$ltcbtc = $arrayRATE['ltcbtc'];
$hashfive = $arrayCOST['cost1'];
$hashthree = $arrayCOST['cost2'];
$hashseven = $arrayCOST['cost3'];
$hashforms = number_format($hashseven,8,'.','');
//------------------------------------------------------------
$PriceBitA = number_format($hashfive,8 ,'.', '');
$PriceBitB = ($usdinbtc / 10000000);
$PriceBitC = ($PriceBitA + $PriceBitB);
//---------bit----------------------------------------
$PriceBitThree = number_format($hashthree,8 ,'.','');
$PriceBitThr = ($usdinbtc / 10000000);
$PrLt = ($ltcusd / 10000000);
$PrLtF = number_format($PrLt,8,'.','');
$PrLtBt = ($ltcbtc / 10000);
$PrLtBtF = number_format($PrLtBt,8,'.','');
$PriceBitTz = (($PriceBitThree - $PriceBitThr) - $PrLtF);
$PriceBitTh = ($PriceBitTz - $PrLtBtF);
//-----------------------------------------------------
$PriceBitD = number_format($PriceBitC,8 ,'.','');
$PriceBitCDm = number_format($PriceBitTh,8 ,'.','');
//---------bit----------------------------------------
$PriceDoge = ($PriceBitC / $dogebtc);
$PriceDogem = ($PriceBitTh / $dogebtc);
$PriceLtc = ($PriceBitC / $ltcbtc);
$PriceLtcm = ($PriceBitTh / $ltcbtc);
//---------doge---------------------------------------
$PriceDogeNF = number_format($PriceDoge, 8,'.', '');
$PriceDogeNFm = number_format($PriceDogem, 8,'.','');
//---------doge---------------------------------------
//---------lite---------------------------------------
$PriceLtcNF = number_format($PriceLtc, 8, '.', '');
$PriceLtcNFm = number_format($PriceLtcm, 8, '.', '');
//---------lite---------------------------------------
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
     	    <style type="text/css">
<!--
@media only screen and ( max-width: 767px) {
#tableOUR{
font-size:7px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#tableOUR{
font-size:7px;
}
}
-->
    </style>
</head>
<body>
  	<script>
function look(type){
param=document.getElementById(type);
if(param.style.display == "none") param.style.display = "block";
else param.style.display = "none"
}
</script>
      <div id="tableOUR">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" Style="color: #00C0EF;">Hash-700mx</h3>
            </div>
            <!-- /.box-header -->
<form class="frmPrice" name="frmPrice" id= "frmPrice" method="post" action="">
 <label>
   <input name="txtPriceB" type="text" id="txtPriceB" value="<?Php echo $hashforms; ?>" hidden>
   </label>
<Label>Hash: &nbsp;</Label>
<input type="number" step="1" value="0" min="0" name="inprdvs" id="inprdvs" Style="border-radius:10px;" required>&nbsp;
<Label>Price: &nbsp;</Label>
<Label id="SumBtc">0.00000000</Label>
<Label>&nbsp;BTC</Label>&nbsp;
<input name="CalcDVS" type="button"  value="Calculate " style="border-radius:10px; cursor: pointer;" title="CALCULATE" onClick="GetPriceDVSm();"><br>
<br>
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Cryptocurrency</th>
                  <th>per day</th>
                  <th>per month</th>
                  <th>per year</th>
                  <th>per three years</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Bitcoin</td>
                  <td><div align="center" id="DDdayB">0.00000000</div>
                  </td>
                  <td><div align="center" id="DDmonthB">0.00000000</div></td>
                  <td><div align="center" id="DDyearB">0.00000000</div></td>
                  <td><div align="center" id="DDthreeB">0.00000000</div></td>
                </tr>
                </tbody>
              </table>
            </div>
            </form>
            <!-- /.box-body -->
          </div>
          </div>
          <!-- /.box -->
    <!-- /.content -->
  </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" Style="color: #605CA8;">Hash-300m</h3>
            </div>
            <!-- /.box-header -->
            <form class="frmPrice1" name="frmPrice1" id= "frmPrice1" method="post" action="">
        <label>
        <input name="txtPrbm" type="text" id="txtPrbm" value="<?Php echo $PriceBitCDm; ?>" hidden>
        <input name="txtPrdm" type="text" id="txtPrdm" value="<?Php echo $PriceDogeNFm; ?>" hidden>
        <input name="txtPrlm" type="text" id="txtPrlm" value="<?Php echo $PriceLtcNFm; ?>" hidden>
        </label>
<Label>Hash: &nbsp;</Label>
<input type="number" step="1" value="0" min="0" name="inprdvs1" id="inprdvs1" Style="border-radius:10px;" required>&nbsp;
<Label>Price: &nbsp;</Label>
<Label id="SumBtc1">0.00000000</Label>
<Label>&nbsp;BTC</Label>&nbsp;
<input name="CalcDVS1" type="button"  value="Calculate " style="border-radius:10px; cursor: pointer;" title="CALCULATE" onClick="GetPriceDVS();"  ><br>
<br>
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Cryptocurrency</th>
                  <th>per day</th>
                  <th>per month</th>
                  <th>per year</th>
                  <th>per three years</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Bitcoin</td>
                  <td><div align="center" id="DDdayBt">0.00000000</div>
                  </td>
                  <td><div align="center" id="DDmonthBt">0.00000000</div></td>
                  <td><div align="center" id="DDyearBt">0.00000000</div></td>
                  <td><div align="center" id="DDthreeBt">0.00000000</div></td>
                </tr>
                </tbody>
                  <tbody>
                <tr>
                  <td>Litecoin</td>
                  <td><div align="center" id="DDdayL">0.00000000</div>
                  </td>
                  <td><div align="center" id="DDmonthL">0.00000000</div></td>
                  <td><div align="center" id="DDyearL">0.00000000</div></td>
                  <td><div align="center" id="DDthreeL">0.00000000</div></td>
                </tr>
                </tbody>
                   <tbody>
                <tr>
                  <td>Dogecoin</td>
                  <td><div align="center" id="DDdayD">0.00000000</div>
                  </td>
                  <td><div align="center" id="DDmonthD">0.00000000</div></td>
                  <td><div align="center" id="DDyearD">0.00000000</div></td>
                  <td><div align="center" id="DDthreeD">0.00000000</div></td>
                </tr>
                </tbody>
              </table>
            </div>
            </form>
            <!-- /.box-body -->
          </div>
          </div>
          <!-- /.box -->
    <!-- /.content -->
  </div>
   <!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" Style="color: #DD4B39;">Hash-500m</h3>
            </div>
            <!-- /.box-header -->
                        <form class="frmPrice2" name="frmPrice2" id= "frmPrice2" method="post" action="">
        <label>
        <input name="txtPrb" type="text" id="txtPrb" value="<?Php echo $PriceBitD; ?>" hidden="hidden" >
        <input name="txtPrd" type="text" id="txtPrd" value="<?Php echo $PriceDogeNF; ?>" hidden="hidden" >
        <input name="txtPrl" type="text" id="txtPrl" value="<?Php echo $PriceLtcNF; ?>" hidden="hidden">
        </label>
<Label>Hash: &nbsp;</Label>
<input type="number" step="1" value="0" min="0" name="inprdvs2" id="inprdvs2" Style="border-radius:10px;" required>&nbsp;
<Label>Price: &nbsp;</Label>
<Label id="SumBtc2">0.00000000</Label>
<Label>&nbsp;BTC</Label>&nbsp;
<input name="CalcDVS2" type="button"  value="Calculate " style="border-radius:10px; cursor: pointer;" title="CALCULATE" onClick="GetPriceDVSsm();"  ><br>
<br>
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Cryptocurrency</th>
                  <th>per day</th>
                  <th>per month</th>
                  <th>per year</th>
                  <th>per three years</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Bitcoin</td> 
                  <td><div align="center" id="DDdayBts">0.00000000</div>
                  </td>
                  <td><div align="center" id="DDmonthBts">0.00000000</div></td>
                  <td><div align="center" id="DDyearBts">0.00000000</div></td>
                  <td><div align="center" id="DDthreeBts">0.00000000</div></td>
                </tr>
                </tbody>
                  <tbody>
                <tr>
                  <td>Litecoin</td>
                  <td><div align="center" id="DDdayLs">0.00000000</div>
                  </td>
                  <td><div align="center" id="DDmonthLs">0.00000000</div></td>
                  <td><div align="center" id="DDyearLs">0.00000000</div></td>
                  <td><div align="center" id="DDthreeLs">0.00000000</div></td>
                </tr>
                </tbody>
                   <tbody>
                <tr>
                  <td>Dogecoin</td>
                  <td><div align="center" id="DDdayDs">0.00000000</div>
                  </td>
                  <td><div align="center" id="DDmonthDs">0.00000000</div></td>
                  <td><div align="center" id="DDyearDs">0.00000000</div></td>
                  <td><div align="center" id="DDthreeDs">0.00000000</div></td>
                </tr>
                </tbody>
              </table>
            </div>
            </form>
            <!-- /.box-body -->
          </div>
          </div>
          <!-- /.box -->
    <!-- /.content -->
  </div>
     <!-- /.row -->
  </div>
<script type="text/javascript">
 function GetPriceDVSm()
 {
 var price_bit = document.frmPrice.txtPriceB.value;
 var dvsm_count = document.frmPrice.inprdvs.value;
 var ourcountBit = (+dvsm_count * +price_bit).toFixed(8);
  var permonthB = (+ourcountBit / 2.9).toFixed(8);
  var perrayB = (+permonthB / 30).toFixed(8);
  var peryearB = (+permonthB * 12).toFixed(8);
  var threeyearsB = (+peryearB * 3).toFixed(8);
 document.getElementById("SumBtc").innerHTML = ourcountBit;
  document.getElementById("DDmonthB").innerHTML = permonthB;
  document.getElementById("DDdayB").innerHTML = perrayB;
  document.getElementById("DDyearB").innerHTML = peryearB;
  document.getElementById("DDthreeB").innerHTML = threeyearsB;
 }
</script>
<script type="text/javascript">
 function GetPriceDVS()
 {
 var price_bitt = document.frmPrice1.txtPrbm.value;
 var price_doge = document.frmPrice1.txtPrdm.value;
 var price_lite = document.frmPrice1.txtPrlm.value;
 var dvsm_countt = document.frmPrice1.inprdvs1.value;
 var ourcountBitt = (+dvsm_countt * +price_bitt).toFixed(8);
 var ourcountDoge = (+dvsm_countt * +price_doge).toFixed(8);
 var ourcountLite = (+dvsm_countt * +price_lite).toFixed(8);
  var permonthBt = (+ourcountBitt / 3.1).toFixed(8);
  var perrayBt = (+permonthBt / 30).toFixed(8);
  var peryearBt = (+permonthBt * 12).toFixed(8);
  var threeyearsBt = (+peryearBt * 3).toFixed(8);
  var permonthD = (+ourcountDoge / 3.1).toFixed(8);
  var perrayD = (+permonthD / 30).toFixed(8);
  var peryearD = (+permonthD * 12).toFixed(8);
  var threeyearsD = (+peryearD * 3).toFixed(8);
  var permonthL = (+ourcountLite / 3.1).toFixed(8);
  var perrayL = (+permonthL / 30).toFixed(8);
  var peryearL = (+permonthL * 12).toFixed(8);
  var threeyearsL = (+peryearL * 3).toFixed(8);
 document.getElementById("SumBtc1").innerHTML = ourcountBitt;
  document.getElementById("DDmonthBt").innerHTML = permonthBt;
  document.getElementById("DDdayBt").innerHTML = perrayBt;
  document.getElementById("DDyearBt").innerHTML = peryearBt;
  document.getElementById("DDthreeBt").innerHTML = threeyearsBt;
  document.getElementById("DDmonthD").innerHTML = permonthD;
  document.getElementById("DDdayD").innerHTML = perrayD;
  document.getElementById("DDyearD").innerHTML = peryearD;
  document.getElementById("DDthreeD").innerHTML = threeyearsD;
  document.getElementById("DDmonthL").innerHTML = permonthL;
  document.getElementById("DDdayL").innerHTML = perrayL;
  document.getElementById("DDyearL").innerHTML = peryearL;
  document.getElementById("DDthreeL").innerHTML = threeyearsL;
 }
</script>
<script type="text/javascript">
 function GetPriceDVSsm()
 {
 var price_bitts = document.frmPrice2.txtPrb.value;
 var price_doges = document.frmPrice2.txtPrd.value;
 var price_lites = document.frmPrice2.txtPrl.value;
 var dvsm_countts = document.frmPrice2.inprdvs2.value;
 var ourcountBitts = (+dvsm_countts * +price_bitts).toFixed(8);
 var ourcountDoges = (+dvsm_countts * +price_doges).toFixed(8);
 var ourcountLites = (+dvsm_countts * +price_lites).toFixed(8);
  var permonthBts = (+ourcountBitts / 3.2).toFixed(8);
  var perrayBts = (+permonthBts / 30).toFixed(8);
  var peryearBts = (+permonthBts * 12).toFixed(8);
  var threeyearsBts = (+peryearBts * 3).toFixed(8);
  var permonthDs = (+ourcountDoges / 3.2).toFixed(8);
  var perrayDs = (+permonthDs / 30).toFixed(8);
  var peryearDs = (+permonthDs * 12).toFixed(8);
  var threeyearsDs = (+peryearDs * 3).toFixed(8);
  var permonthLs = (+ourcountLites / 3.2).toFixed(8);
  var perrayLs = (+permonthLs / 30).toFixed(8);
  var peryearLs = (+permonthLs * 12).toFixed(8);
  var threeyearsLs = (+peryearLs * 3).toFixed(8);
  document.getElementById("SumBtc2").innerHTML = ourcountBitts;
  document.getElementById("DDmonthBts").innerHTML = permonthBts;
  document.getElementById("DDdayBts").innerHTML = perrayBts;
  document.getElementById("DDyearBts").innerHTML = peryearBts;
  document.getElementById("DDthreeBts").innerHTML = threeyearsBts;
  document.getElementById("DDmonthDs").innerHTML = permonthDs;
  document.getElementById("DDdayDs").innerHTML = perrayDs;
  document.getElementById("DDyearDs").innerHTML = peryearDs;
  document.getElementById("DDthreeDs").innerHTML = threeyearsDs;
  document.getElementById("DDmonthLs").innerHTML = permonthLs;
  document.getElementById("DDdayLs").innerHTML = perrayLs;
  document.getElementById("DDyearLs").innerHTML = peryearLs;
  document.getElementById("DDthreeLs").innerHTML = threeyearsLs;
 }
</script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
</body>
</html>