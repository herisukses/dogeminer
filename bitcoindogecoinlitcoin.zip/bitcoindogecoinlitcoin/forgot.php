<?php
include_once('bd.php');
if (isset($_POST['submit'])){
	$login = $_POST['login'];
	$email = $_POST['email'];

	if (empty($login)){
		echo "Enter login!";
	}
	elseif (empty($email)){
		echo "Enter e-mail!";
	}
   else{
		$resultat = mysql_query("SELECT * FROM gusers WHERE glogin = '$login' AND email = '$email'");
		$array = mysql_fetch_array($resultat);
		if (empty($array)){
			echo 'Error! This user does not exist';
		}
		elseif (mysql_num_rows($resultat) > 0){
			$chars="qazxswedcvfrtgbnhyujmkiolp1234567890QAZXSWEDCVFRTGBNHYUJMKIOLP";
			$max=10;
			$size=StrLen($chars)-1;
			$password=null;

			while($max--){
			$password.=$chars[rand(0,$size)];
			}
			$newmdPassword = md5($password);
            $from = 'admin@z-files.site';
			$title = 'Password recovery fot user '.$login.' tccmining.com!';
			$headerd = "From: \"Admin\" <admin@z-files.site\n";
            $headerd .= "Content-type: text/plain; charset=\"utf-8\"";
			$letter = 	'You asked for the account password recovery '.$login.'  tccmining.com \r\nYour new password: '.$password;
            mail($email, $title, $letter, $headerd);
            //----------------------
               $connect = fsockopen ('127.0.0.1', 25, $errno, $errstr, 30);
        if(!$connect){
            echo json_encode($errno);
        } else {
            fputs($connect, "HELO localhost\r\n");
            fputs($connect, "MAIL FROM: $from\n");
            fputs($connect, "RCPT TO: $email\n");
            fputs($connect, "DATA\r\n");
            fputs($connect, "Content-Type: text/plain; charset=UTF-8");
            fputs($connect, "MIME-Version: 1.0\nContent-Transfer-Encoding: 7bit\n");
            fputs($connect, "To: $email\r\n");
            fputs($connect, "Subject: =?utf-8?b?".base64_encode($title)."?=\r\n");
            fputs($connect, $letter." \r\n");
            fputs($connect, ".\r\n");
            fputs($connect, "RSET\r\n");
             mysql_query("UPDATE gusers SET gpassword = '$newmdPassword' WHERE glogin = '$login'  AND gusers.email = '$email'");
			   mysql_query("UPDATE ltcdoge SET fpassword = '$newmdPassword' WHERE flogin='$login' AND ltcdoge.email='$email'");
			   mysql_query("UPDATE ltcdogeming SET vpassword = '$newmdPassword' WHERE vlogin='$login' AND ltcdogeming.email='$email'");
               mysql_query("UPDATE greffer SET rrpassword = '$newmdPassword' WHERE rlogin='$login' AND greffer.email='$email'");
               mysql_query("UPDATE gsmcnew SET spassword = '$newmdPassword' WHERE slogin='$login' AND gsmcnew.email='$email'");
			   echo 'New password sent to your e-mail!<br><a href="index.php">...Main</a>';
        }
        fclose($connect);
            //-----------------------
		}
	}
}
mysql_close();
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>TCC</title>
        <link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1 id="logo"><a href="main.html">TCC<span> Cloud mining cryptocurrency</span></a></h1>
					<nav id="nav">
						<ul>
							<li class="submenu">
								<a href="#">Menu</a>
								<ul>
                                    <li><a href="index.php">Main</a></li>
									<li><a href="#">Calculate</a></li>
									<li><a href="faq.html">Faq</a></li>
									<li><a href="news.php">News</a></li>
									<li><a href="support.php">Support</a></li>
								</ul>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">

					<!--
						".inner" is set up as an inline-block so it automatically expands
						in both directions to fit whatever's inside it. This means it won't
						automatically wrap lines, so be sure to use line breaks where
						appropriate (<br />).
					-->
					<div class="inner">

						<header>
							<h2>TCC mining</h2>
						</header>
      <div id="pafor">
      <form method="POST">
      <input type="text" size="20" name="login"  placeholder="login" Style="border-radius: 10px;" required > <br>
      <input type="text" size="20" name="email" placeholder="e-mail" Style="border-radius: 10px;" required >  <br>
      <input type="submit" value="Password recovery" name="submit" style="cursor: pointer; border-radius: 10px;" title="RECOVERY" >
     <br>
      </form>
			</div>
						<footer>

						</footer>
					</div>

				</section>

			<!-- Footer -->
				<footer id="footer">

					<ul class="copyright">
						<li>&copy; 2017 TCC All Rights Reserved.</li>
					</ul>

				</footer>

		</div>

		<!-- Scripts -->
             <script>
               function look(type){
                param=document.getElementById(type);
                if(param.style.display == "none") param.style.display = "block";
                else param.style.display = "none"
             }
            </script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>